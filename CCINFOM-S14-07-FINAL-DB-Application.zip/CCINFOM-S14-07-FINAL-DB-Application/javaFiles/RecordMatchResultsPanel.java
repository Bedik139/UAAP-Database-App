import java.awt.*;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

/**
 * Transaction 3: Recording Match Results & Stats Panel
 * Assigned to: REYES, Ivan Kenneth C.
 * 
 * UI for recording complete match results including:
 * - Match completion
 * - Player statistics updates
 * - Team standings updates
 * - View completed matches with statistics
 */
public class RecordMatchResultsPanel extends JPanel {

    private final MatchResultService matchResultService = new MatchResultService();
    private final MatchDAO matchDAO = new MatchDAO();
    private final MatchTeamDAO matchTeamDAO = new MatchTeamDAO();
    private final PlayerDAO playerDAO = new PlayerDAO();

    private JComboBox<MatchWrapper> matchCombo;
    private JLabel team1Label;
    private JLabel team2Label;
    private JLabel team1ScoreLabel;
    private JLabel team2ScoreLabel;
    private JTable playerStatsTable;
    private DefaultTableModel playerStatsModel;
    private JTextArea resultArea;
    private JButton recordButton;
    private JButton refreshButton;
    private JButton clearButton;

    // Completed matches view components
    private JTable completedMatchesTable;
    private DefaultTableModel completedMatchesModel;
    private JButton refreshCompletedButton;

    private int selectedMatchId = -1;
    private List<MatchTeam> currentMatchTeams;

    public RecordMatchResultsPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(UAAPTheme.LIGHT_SURFACE);
        setBorder(new EmptyBorder(15, 15, 15, 15));

        // Create tabbed pane for Record and View modes
        JTabbedPane tabbedPane = new JTabbedPane();
        UAAPTheme.styleTabPane(tabbedPane);

        // Tab 1: Record Match Results
        JPanel recordPanel = createRecordPanel();
        tabbedPane.addTab("Record Match Results", recordPanel);

        // Tab 2: View Completed Matches
        JPanel viewPanel = createViewCompletedPanel();
        tabbedPane.addTab("View Completed Matches", viewPanel);

        add(tabbedPane, BorderLayout.CENTER);

        loadUncompletedMatches();
        loadCompletedMatches();
    }

    private JPanel createRecordPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setOpaque(false);

        panel.add(createHeaderPanel(), BorderLayout.NORTH);
        panel.add(createCenterPanel(), BorderLayout.CENTER);
        panel.add(createButtonPanel(), BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setOpaque(false);

        // Title
        JLabel titleLabel = new JLabel("Record Match Results & Statistics");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(UAAPTheme.PRIMARY_GREEN);

        JLabel subtitleLabel = new JLabel("Complete match results and update player stats & team standings");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitleLabel.setForeground(UAAPTheme.TEXT_SECONDARY);

        JPanel titlePanel = new JPanel(new GridLayout(2, 1, 0, 3));
        titlePanel.setOpaque(false);
        titlePanel.add(titleLabel);
        titlePanel.add(subtitleLabel);

        panel.add(titlePanel, BorderLayout.NORTH);
        panel.add(createMatchSelectionPanel(), BorderLayout.CENTER);

        return panel;
    }

    private JPanel createMatchSelectionPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(UAAPTheme.CARD_BACKGROUND);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UAAPTheme.CARD_BORDER, 2),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        // Match selection
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel matchLabel = new JLabel("Select Match:");
        matchLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        matchLabel.setForeground(UAAPTheme.TEXT_PRIMARY);
        panel.add(matchLabel, gbc);

        gbc.gridx = 1;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        matchCombo = new JComboBox<>();
        matchCombo.setPreferredSize(new Dimension(500, 35));
        matchCombo.addActionListener(e -> onMatchSelected());
        UAAPTheme.styleComboBox(matchCombo);
        panel.add(matchCombo, gbc);

        // Team 1 info
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.weightx = 0.0;
        gbc.fill = GridBagConstraints.NONE;
        JLabel team1TitleLabel = new JLabel("Home Team:");
        team1TitleLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        team1TitleLabel.setForeground(UAAPTheme.TEXT_PRIMARY);
        panel.add(team1TitleLabel, gbc);

        gbc.gridx = 1;
        team1Label = new JLabel("-");
        team1Label.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        team1Label.setForeground(UAAPTheme.TEXT_SECONDARY);
        panel.add(team1Label, gbc);

        gbc.gridx = 2;
        JLabel team1ScoreTitleLabel = new JLabel("Score:");
        team1ScoreTitleLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        team1ScoreTitleLabel.setForeground(UAAPTheme.TEXT_PRIMARY);
        panel.add(team1ScoreTitleLabel, gbc);

        gbc.gridx = 3;
        team1ScoreLabel = new JLabel("-");
        team1ScoreLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        team1ScoreLabel.setForeground(UAAPTheme.PRIMARY_GREEN);
        panel.add(team1ScoreLabel, gbc);

        // Team 2 info
        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel team2TitleLabel = new JLabel("Away Team:");
        team2TitleLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        team2TitleLabel.setForeground(UAAPTheme.TEXT_PRIMARY);
        panel.add(team2TitleLabel, gbc);

        gbc.gridx = 1;
        team2Label = new JLabel("-");
        team2Label.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        team2Label.setForeground(UAAPTheme.TEXT_SECONDARY);
        panel.add(team2Label, gbc);

        gbc.gridx = 2;
        JLabel team2ScoreTitleLabel = new JLabel("Score:");
        team2ScoreTitleLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        team2ScoreTitleLabel.setForeground(UAAPTheme.TEXT_PRIMARY);
        panel.add(team2ScoreTitleLabel, gbc);

        gbc.gridx = 3;
        team2ScoreLabel = new JLabel("-");
        team2ScoreLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        team2ScoreLabel.setForeground(UAAPTheme.PRIMARY_GREEN);
        panel.add(team2ScoreLabel, gbc);

        return panel;
    }

    private JPanel createCenterPanel() {
        JPanel panel = new JPanel(new GridLayout(1, 2, 15, 0));
        panel.setOpaque(false);

        panel.add(createPlayerStatsPanel());
        panel.add(createResultPanel());

        return panel;
    }

    private JPanel createPlayerStatsPanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBackground(UAAPTheme.CARD_BACKGROUND);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UAAPTheme.CARD_BORDER, 2),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        JLabel titleLabel = new JLabel("Player Statistics (Points to Add)");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        titleLabel.setForeground(UAAPTheme.TEXT_PRIMARY);
        panel.add(titleLabel, BorderLayout.NORTH);

        // Player stats table
        playerStatsModel = new DefaultTableModel(
            new Object[]{"Player ID", "Player Name", "Team", "Current Total Score", "Points to Add"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 4; // Only "Points to Add" column is editable
            }

            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 4) return Integer.class;
                return String.class;
            }
        };

        playerStatsTable = new JTable(playerStatsModel);
        playerStatsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        playerStatsTable.getColumnModel().getColumn(4).setPreferredWidth(100);
        UAAPTheme.styleTable(playerStatsTable);

        JScrollPane scrollPane = new JScrollPane(playerStatsTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        UAAPTheme.elevate(scrollPane);
        panel.add(scrollPane, BorderLayout.CENTER);

        JLabel infoLabel = new JLabel("Enter points scored by each player in this match");
        infoLabel.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        infoLabel.setForeground(UAAPTheme.TEXT_SECONDARY);
        panel.add(infoLabel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createResultPanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBackground(UAAPTheme.CARD_BACKGROUND);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UAAPTheme.CARD_BORDER, 2),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        JLabel titleLabel = new JLabel("Transaction Results");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        titleLabel.setForeground(UAAPTheme.TEXT_PRIMARY);
        panel.add(titleLabel, BorderLayout.NORTH);

        resultArea = new JTextArea();
        resultArea.setEditable(false);
        resultArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        resultArea.setBackground(new Color(250, 250, 250));
        resultArea.setForeground(UAAPTheme.TEXT_PRIMARY);
        resultArea.setBorder(new EmptyBorder(10, 10, 10, 10));
        resultArea.setText("Select a match and enter player statistics,\nthen click 'Record Match Results' to complete\nthe transaction.\n\nThis will:\n  • Update match status to 'Completed'\n  • Update player individual scores\n  • Update team win/loss standings");

        JScrollPane scrollPane = new JScrollPane(resultArea);
        scrollPane.setBorder(BorderFactory.createLineBorder(UAAPTheme.CARD_BORDER));
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 15));
        panel.setBackground(UAAPTheme.LIGHT_SURFACE);
        panel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UAAPTheme.CARD_BORDER));

        recordButton = new JButton("Record Match Results");
        refreshButton = new JButton("Refresh Matches");
        clearButton = new JButton("Clear Form");

        UAAPTheme.styleActionButton(recordButton);
        UAAPTheme.styleInfoButton(refreshButton);
        UAAPTheme.styleNeutralButton(clearButton);

        recordButton.addActionListener(e -> recordMatchResults());
        refreshButton.addActionListener(e -> {
            loadUncompletedMatches();
            clearForm();
        });
        clearButton.addActionListener(e -> clearForm());

        panel.add(recordButton);
        panel.add(refreshButton);
        panel.add(clearButton);

        return panel;
    }

    private void loadUncompletedMatches() {
        try {
            List<Match> allMatches = matchDAO.getAllMatches();
            DefaultComboBoxModel<MatchWrapper> model = new DefaultComboBoxModel<>();

            for (Match match : allMatches) {
                if (!"Completed".equalsIgnoreCase(match.getStatus())) {
                    model.addElement(new MatchWrapper(match));
                }
            }

            matchCombo.setModel(model);
            if (model.getSize() > 0) {
                matchCombo.setSelectedIndex(0);
            }
        } catch (SQLException ex) {
            showError("Failed to load matches: " + ex.getMessage());
        }
    }

    private void onMatchSelected() {
        MatchWrapper wrapper = (MatchWrapper) matchCombo.getSelectedItem();
        if (wrapper == null) {
            clearMatchInfo();
            return;
        }

        selectedMatchId = wrapper.match.getMatchId();
        loadMatchDetails(selectedMatchId);
    }

    private void loadMatchDetails(int matchId) {
        try {
            // Load match teams
            currentMatchTeams = matchTeamDAO.getMatchTeamsForMatch(matchId);
            if (currentMatchTeams.size() == 2) {
                MatchTeam team1 = currentMatchTeams.get(0);
                MatchTeam team2 = currentMatchTeams.get(1);

                team1Label.setText(team1.getTeamName());
                team2Label.setText(team2.getTeamName());
                team1ScoreLabel.setText(String.valueOf(team1.getTeamScore()));
                team2ScoreLabel.setText(String.valueOf(team2.getTeamScore()));
            }

            // Load players from both teams
            loadPlayersForMatch(currentMatchTeams);

        } catch (SQLException ex) {
            showError("Failed to load match details: " + ex.getMessage());
        }
    }

    private void loadPlayersForMatch(List<MatchTeam> matchTeams) throws SQLException {
        playerStatsModel.setRowCount(0);

        for (MatchTeam matchTeam : matchTeams) {
            List<Player> players = playerDAO.getPlayersByTeam(matchTeam.getTeamId());
            for (Player player : players) {
                playerStatsModel.addRow(new Object[]{
                    player.getPlayerId(),
                    player.getFirstName() + " " + player.getLastName(),
                    matchTeam.getTeamName(),
                    player.getIndividualScore(),
                    0 // Default points to add
                });
            }
        }
    }

    private void recordMatchResults() {
        if (selectedMatchId == -1) {
            showError("Please select a match first");
            return;
        }

        if (currentMatchTeams == null || currentMatchTeams.size() != 2) {
            showError("Match must have exactly 2 teams");
            return;
        }

        // Collect player points from table
        Map<Integer, Integer> playerPointsMap = new HashMap<>();
        for (int i = 0; i < playerStatsModel.getRowCount(); i++) {
            int playerId = (Integer) playerStatsModel.getValueAt(i, 0);
            Object pointsObj = playerStatsModel.getValueAt(i, 4);
            int pointsToAdd = (pointsObj instanceof Integer) ? (Integer) pointsObj : 0;
            
            if (pointsToAdd > 0) {
                playerPointsMap.put(playerId, pointsToAdd);
            }
        }

        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Record match results? This will:\n" +
            "• Mark match as Completed\n" +
            "• Update " + playerPointsMap.size() + " player statistics\n" +
            "• Update team standings",
            "Confirm Transaction",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            resultArea.setText("Processing transaction...\n\n");
            
            // Execute the transaction
            matchResultService.recordMatchResults(selectedMatchId, playerPointsMap);

            // Build success message
            StringBuilder result = new StringBuilder();
            result.append("✓ TRANSACTION COMPLETED SUCCESSFULLY\n\n");
            result.append("═══════════════════════════════════\n\n");
            
            result.append("Operation A: Match Retrieved\n");
            result.append("  Match ID: ").append(selectedMatchId).append("\n\n");
            
            result.append("Operation B: Match Status Updated\n");
            result.append("  Status: Completed\n");
            result.append("  Score: ").append(team1Label.getText()).append(" ")
                  .append(team1ScoreLabel.getText()).append(" - ")
                  .append(team2Label.getText()).append(" ")
                  .append(team2ScoreLabel.getText()).append("\n\n");
            
            result.append("Operation C: Player Stats Updated\n");
            result.append("  Players affected: ").append(playerPointsMap.size()).append("\n");
            for (Map.Entry<Integer, Integer> entry : playerPointsMap.entrySet()) {
                result.append("  • Player ").append(entry.getKey())
                      .append(": +").append(entry.getValue()).append(" points\n");
            }
            result.append("\n");
            
            result.append("Operation D: Team Standings Updated\n");
            int team1Score = Integer.parseInt(team1ScoreLabel.getText());
            int team2Score = Integer.parseInt(team2ScoreLabel.getText());
            
            if (team1Score > team2Score) {
                result.append("  Winner: ").append(team1Label.getText()).append(" (+1 Win)\n");
                result.append("  Loser: ").append(team2Label.getText()).append(" (+1 Loss)\n");
            } else if (team2Score > team1Score) {
                result.append("  Winner: ").append(team2Label.getText()).append(" (+1 Win)\n");
                result.append("  Loser: ").append(team1Label.getText()).append(" (+1 Loss)\n");
            } else {
                result.append("  Tie: Both teams (+1 Game Played)\n");
            }

            resultArea.setText(result.toString());
            
            showInfo("Match results recorded successfully!");
            loadUncompletedMatches();
            clearForm();

        } catch (Exception ex) {
            resultArea.setText("✗ TRANSACTION FAILED\n\n" + ex.getMessage());
            showError("Failed to record match results:\n" + ex.getMessage());
        }
    }

    private void clearForm() {
        selectedMatchId = -1;
        currentMatchTeams = null;
        clearMatchInfo();
        playerStatsModel.setRowCount(0);
        resultArea.setText("Select a match and enter player statistics,\nthen click 'Record Match Results' to complete\nthe transaction.\n\nThis will:\n  • Update match status to 'Completed'\n  • Update player individual scores\n  • Update team win/loss standings");
    }

    private void clearMatchInfo() {
        team1Label.setText("-");
        team2Label.setText("-");
        team1ScoreLabel.setText("-");
        team2ScoreLabel.setText("-");
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void showInfo(String message) {
        JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    // ===== VIEW COMPLETED MATCHES SECTION =====

    private JPanel createViewCompletedPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setOpaque(false);

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout(10, 10));
        headerPanel.setOpaque(false);

        JLabel titleLabel = new JLabel("Completed Matches History");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(UAAPTheme.PRIMARY_GREEN);

        JLabel subtitleLabel = new JLabel("View all completed matches with results and statistics");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitleLabel.setForeground(UAAPTheme.TEXT_SECONDARY);

        JPanel titlePanel = new JPanel(new GridLayout(2, 1, 0, 3));
        titlePanel.setOpaque(false);
        titlePanel.add(titleLabel);
        titlePanel.add(subtitleLabel);

        headerPanel.add(titlePanel, BorderLayout.CENTER);
        panel.add(headerPanel, BorderLayout.NORTH);

        // Completed matches table
        JPanel tablePanel = new JPanel(new BorderLayout(0, 10));
        tablePanel.setBackground(UAAPTheme.CARD_BACKGROUND);
        tablePanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UAAPTheme.CARD_BORDER, 2),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        JLabel tableTitleLabel = new JLabel("Completed Matches");
        tableTitleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tableTitleLabel.setForeground(UAAPTheme.TEXT_PRIMARY);
        tablePanel.add(tableTitleLabel, BorderLayout.NORTH);

        completedMatchesModel = new DefaultTableModel(
            new Object[]{"Match ID", "Event", "Match Type", "Team 1", "Score 1", "Score 2", "Team 2", "Winner", "Status"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // All cells are non-editable
            }
        };

        completedMatchesTable = new JTable(completedMatchesModel);
        completedMatchesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        UAAPTheme.styleTable(completedMatchesTable);

        JScrollPane scrollPane = new JScrollPane(completedMatchesTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        UAAPTheme.elevate(scrollPane);
        tablePanel.add(scrollPane, BorderLayout.CENTER);

        panel.add(tablePanel, BorderLayout.CENTER);

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 15));
        buttonPanel.setBackground(UAAPTheme.LIGHT_SURFACE);
        buttonPanel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UAAPTheme.CARD_BORDER));

        refreshCompletedButton = new JButton("Refresh List");
        UAAPTheme.styleInfoButton(refreshCompletedButton);
        refreshCompletedButton.addActionListener(e -> loadCompletedMatches());

        JButton viewDetailsButton = new JButton("View Match Details");
        UAAPTheme.styleActionButton(viewDetailsButton);
        viewDetailsButton.addActionListener(e -> viewSelectedMatchDetails());

        buttonPanel.add(viewDetailsButton);
        buttonPanel.add(refreshCompletedButton);

        panel.add(buttonPanel, BorderLayout.SOUTH);

        return panel;
    }

    private void loadCompletedMatches() {
        completedMatchesModel.setRowCount(0);
        
        try {
            List<Match> allMatches = matchDAO.getAllMatches();
            
            // Sort matches: Basketball first, then Volleyball
            allMatches.sort((m1, m2) -> {
                // Extract sport from event name (e.g., "UAAP S87 Basketball - Finals")
                String sport1 = extractSportFromEventName(m1.getEventName());
                String sport2 = extractSportFromEventName(m2.getEventName());
                
                // Basketball comes before Volleyball
                if (sport1.equals(sport2)) {
                    return 0; // Same sport, keep original order
                } else if ("Basketball".equalsIgnoreCase(sport1)) {
                    return -1; // Basketball comes first
                } else if ("Basketball".equalsIgnoreCase(sport2)) {
                    return 1; // Basketball comes first
                } else {
                    return sport1.compareTo(sport2); // Alphabetical for others
                }
            });
            
            for (Match match : allMatches) {
                if ("Completed".equalsIgnoreCase(match.getStatus())) {
                    // Get match teams for this match
                    List<MatchTeam> matchTeams = matchTeamDAO.getMatchTeamsForMatch(match.getMatchId());
                    
                    String team1Name = "-";
                    String team2Name = "-";
                    int team1Score = 0;
                    int team2Score = 0;
                    String winner = "-";
                    
                    if (matchTeams.size() >= 2) {
                        MatchTeam team1 = matchTeams.get(0);
                        MatchTeam team2 = matchTeams.get(1);
                        
                        team1Name = team1.getTeamName();
                        team2Name = team2.getTeamName();
                        team1Score = team1.getTeamScore();
                        team2Score = team2.getTeamScore();
                        
                        // Skip matches with 0-0 score (incomplete data)
                        if (team1Score == 0 && team2Score == 0) {
                            continue;
                        }
                        
                        if (team1Score > team2Score) {
                            winner = team1Name;
                        } else if (team2Score > team1Score) {
                            winner = team2Name;
                        } else {
                            winner = "TIE";
                        }
                    }
                    
                    completedMatchesModel.addRow(new Object[]{
                        match.getMatchId(),
                        match.getEventName(),
                        match.getMatchType(),
                        team1Name,
                        team1Score,
                        team2Score,
                        team2Name,
                        winner,
                        match.getStatus()
                    });
                }
            }
        } catch (SQLException ex) {
            showError("Failed to load completed matches: " + ex.getMessage());
        }
    }

    private void viewSelectedMatchDetails() {
        int selectedRow = completedMatchesTable.getSelectedRow();
        if (selectedRow == -1) {
            showError("Please select a match to view details");
            return;
        }

        int matchId = (Integer) completedMatchesModel.getValueAt(selectedRow, 0);
        
        try {
            // Get match details
            Match match = matchDAO.getMatchById(matchId);
            List<MatchTeam> matchTeams = matchTeamDAO.getMatchTeamsForMatch(matchId);
            
            if (match == null || matchTeams.size() < 2) {
                showError("Failed to retrieve match details");
                return;
            }

            MatchTeam team1 = matchTeams.get(0);
            MatchTeam team2 = matchTeams.get(1);

            // Build details message
            StringBuilder details = new StringBuilder();
            details.append("═══════════════════════════════════\n");
            details.append("        MATCH DETAILS\n");
            details.append("═══════════════════════════════════\n\n");
            
            details.append("Match ID: ").append(match.getMatchId()).append("\n");
            details.append("Event: ").append(match.getEventName()).append("\n");
            details.append("Match Type: ").append(match.getMatchType()).append("\n");
            details.append("Status: ").append(match.getStatus()).append("\n\n");
            
            details.append("───────────────────────────────────\n");
            details.append("         FINAL SCORE\n");
            details.append("───────────────────────────────────\n\n");
            
            details.append(String.format("%-25s %3d\n", team1.getTeamName(), team1.getTeamScore()));
            details.append(String.format("%-25s %3d\n", team2.getTeamName(), team2.getTeamScore()));
            details.append("\n");
            
            if (team1.getTeamScore() > team2.getTeamScore()) {
                details.append("Winner: ").append(team1.getTeamName()).append(" 🏆\n");
            } else if (team2.getTeamScore() > team1.getTeamScore()) {
                details.append("Winner: ").append(team2.getTeamName()).append(" 🏆\n");
            } else {
                details.append("Result: TIE\n");
            }
            
            details.append("\n");
            
            if (match.getScoreSummary() != null && !match.getScoreSummary().isEmpty()) {
                details.append("───────────────────────────────────\n");
                details.append("       SCORE BREAKDOWN\n");
                details.append("───────────────────────────────────\n\n");
                details.append(match.getScoreSummary()).append("\n");
            }

            // Show in dialog
            JTextArea detailsArea = new JTextArea(details.toString());
            detailsArea.setEditable(false);
            detailsArea.setFont(new Font("Consolas", Font.PLAIN, 12));
            detailsArea.setBackground(new Color(250, 250, 250));
            detailsArea.setForeground(UAAPTheme.TEXT_PRIMARY);
            detailsArea.setBorder(new EmptyBorder(15, 15, 15, 15));

            JScrollPane scrollPane = new JScrollPane(detailsArea);
            scrollPane.setPreferredSize(new Dimension(500, 400));

            JOptionPane.showMessageDialog(
                this,
                scrollPane,
                "Match Details - ID: " + matchId,
                JOptionPane.INFORMATION_MESSAGE
            );

        } catch (SQLException ex) {
            showError("Failed to retrieve match details: " + ex.getMessage());
        }
    }

    /**
     * Helper method to extract sport from event name
     * E.g., "UAAP S87 Basketball - Finals" -> "Basketball"
     */
    private String extractSportFromEventName(String eventName) {
        if (eventName == null) return "";
        
        // Event names follow format: "UAAP S## Sport - EventType"
        if (eventName.contains("Basketball")) {
            return "Basketball";
        } else if (eventName.contains("Volleyball")) {
            return "Volleyball";
        }
        return "Other";
    }

    /**
     * Wrapper class for displaying matches in combo box
     */
    private static class MatchWrapper {
        final Match match;

        MatchWrapper(Match match) {
            this.match = match;
        }

        @Override
        public String toString() {
            return String.format("[ID: %d] %s - %s (%s)",
                match.getMatchId(),
                match.getEventName(),
                match.getMatchType(),
                match.getStatus());
        }
    }
}
