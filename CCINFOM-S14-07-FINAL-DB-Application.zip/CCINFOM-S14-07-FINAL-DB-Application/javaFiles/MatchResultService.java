import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Transaction 3: Recording Match Results & Stats
 * Assigned to: REYES, Ivan Kenneth C.
 * 
 * This service orchestrates the complete match result recording workflow:
 * a. Retrieve the Match record to be updated
 * b. Update the Match record with final score and set Status to 'Completed'
 * c. Update Player records with individual statistics
 * d. Update Team records with win/loss totals
 */
public class MatchResultService {

    private final MatchDAO matchDAO = new MatchDAO();
    private final MatchTeamDAO matchTeamDAO = new MatchTeamDAO();
    private final TeamDAO teamDAO = new TeamDAO();
    private final PlayerDAO playerDAO = new PlayerDAO();
    private final ScoreAggregationService scoreAggregationService = new ScoreAggregationService();

    /**
     * Records complete match results in a single transaction.
     * This includes updating match status, player stats, and team standings.
     */
    public void recordMatchResults(int matchId, Map<Integer, Integer> playerPointsMap) throws SQLException {
        Connection conn = null;
        boolean originalAutoCommit = true;

        try {
            conn = Database.getConnection();
            originalAutoCommit = conn.getAutoCommit();
            conn.setAutoCommit(false); // Start transaction

            // Operation A: Retrieve the Match record to be updated
            Match match = matchDAO.getMatchById(matchId);
            if (match == null) {
                throw new IllegalArgumentException("Match not found with ID: " + matchId);
            }

            if ("Completed".equalsIgnoreCase(match.getStatus())) {
                throw new IllegalStateException("Match is already completed");
            }

            // Get the teams in this match
            List<MatchTeam> matchTeams = matchTeamDAO.getMatchTeamsForMatch(matchId);
            if (matchTeams.size() != 2) {
                throw new IllegalStateException("Match must have exactly 2 teams");
            }

            // Ensure scores have been aggregated from quarter/set scores
            scoreAggregationService.updateTotalsForMatch(matchId);

            // Refresh match teams to get updated scores
            matchTeams = matchTeamDAO.getMatchTeamsForMatch(matchId);

            // Operation B: Update the Match record with final score and set Status to 'Completed'
            updateMatchToCompleted(conn, matchId);

            // Operation C: Update Player records with individual statistics
            updatePlayerStatistics(conn, playerPointsMap);

            // Operation D: Update Team records with win/loss totals
            updateTeamStandings(conn, matchTeams);

            conn.commit(); // Commit transaction
        } catch (Exception e) {
            if (conn != null) {
                try {
                    conn.rollback(); // Rollback on error
                } catch (SQLException rollbackEx) {
                    throw new SQLException("Rollback failed: " + rollbackEx.getMessage(), rollbackEx);
                }
            }
            throw new SQLException("Failed to record match results: " + e.getMessage(), e);
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(originalAutoCommit);
                    conn.close();
                } catch (SQLException closeEx) {
                    // Log but don't throw
                }
            }
        }
    }

    /**
     * Operation B: Update match status to 'Completed' and regenerate score summary
     */
    private void updateMatchToCompleted(Connection conn, int matchId) throws SQLException {
        // First get the current score summary from aggregation
        String sql = "SELECT score_summary FROM `match` WHERE match_id = ?";
        String scoreSummary = null;
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, matchId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    scoreSummary = rs.getString("score_summary");
                }
            }
        }

        // Update status to Completed
        String updateSql = "UPDATE `match` SET status = 'Completed', score_summary = ? WHERE match_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(updateSql)) {
            ps.setString(1, scoreSummary);
            ps.setInt(2, matchId);
            ps.executeUpdate();
        }
    }

    /**
     * Operation C: Update player individual statistics (points scored)
     */
    private void updatePlayerStatistics(Connection conn, Map<Integer, Integer> playerPointsMap) throws SQLException {
        if (playerPointsMap == null || playerPointsMap.isEmpty()) {
            return; // No player stats to update
        }

        String sql = "UPDATE player SET individual_score = individual_score + ? WHERE player_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            for (Map.Entry<Integer, Integer> entry : playerPointsMap.entrySet()) {
                int playerId = entry.getKey();
                int pointsToAdd = entry.getValue();
                
                if (pointsToAdd > 0) {
                    ps.setInt(1, pointsToAdd);
                    ps.setInt(2, playerId);
                    ps.addBatch();
                }
            }
            ps.executeBatch();
        }
    }

    /**
     * Operation D: Update team win/loss totals based on match outcome
     */
    private void updateTeamStandings(Connection conn, List<MatchTeam> matchTeams) throws SQLException {
        if (matchTeams.size() != 2) {
            throw new IllegalArgumentException("Must have exactly 2 teams");
        }

        MatchTeam team1 = matchTeams.get(0);
        MatchTeam team2 = matchTeams.get(1);

        int winningTeamId;
        int losingTeamId;

        if (team1.getTeamScore() > team2.getTeamScore()) {
            winningTeamId = team1.getTeamId();
            losingTeamId = team2.getTeamId();
        } else if (team2.getTeamScore() > team1.getTeamScore()) {
            winningTeamId = team2.getTeamId();
            losingTeamId = team1.getTeamId();
        } else {
            // It's a tie - increment total_games_played only
            incrementGamesPlayed(conn, team1.getTeamId());
            incrementGamesPlayed(conn, team2.getTeamId());
            return;
        }

        // Update winning team
        String winSql = "UPDATE team SET standing_wins = standing_wins + 1, " +
                        "total_games_played = total_games_played + 1 WHERE team_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(winSql)) {
            ps.setInt(1, winningTeamId);
            ps.executeUpdate();
        }

        // Update losing team
        String lossSql = "UPDATE team SET standing_losses = standing_losses + 1, " +
                         "total_games_played = total_games_played + 1 WHERE team_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(lossSql)) {
            ps.setInt(1, losingTeamId);
            ps.executeUpdate();
        }
    }

    /**
     * Helper method to increment games played for ties
     */
    private void incrementGamesPlayed(Connection conn, int teamId) throws SQLException {
        String sql = "UPDATE team SET total_games_played = total_games_played + 1 WHERE team_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, teamId);
            ps.executeUpdate();
        }
    }

    /**
     * Retrieves team standings for a specific team
     */
    public Team getTeamStandings(int teamId) throws SQLException {
        try (Connection conn = Database.getConnection()) {
            String sql = "SELECT team_id, team_name, gender, sport, seasons_played, " +
                        "standing_wins, standing_losses, total_games_played FROM team WHERE team_id = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, teamId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return new Team(
                            rs.getInt("team_id"),
                            rs.getString("team_name"),
                            rs.getString("gender"),
                            rs.getString("sport"),
                            rs.getInt("seasons_played"),
                            rs.getInt("standing_wins"),
                            rs.getInt("standing_losses"),
                            rs.getInt("total_games_played")
                        );
                    }
                }
            }
        }
        return null;
    }
}
