import java.awt.*;
import java.sql.SQLException;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class CustomerManagerPanel extends JPanel {

    private final CustomerDAO customerDAO = new CustomerDAO();
    private JTable customerTable;
    private DefaultTableModel customerTableModel;
    
    // Form fields
    private JTextField idField;
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField emailField;
    private JTextField phoneField;
    private JTextField organizationField;
    private JTextField preferredTeamField;
    private JComboBox<String> statusCombo;
    private JComboBox<String> paymentMethodCombo;
    
    private JButton addButton;
    private JButton updateButton;
    private JButton deleteButton;
    private JButton clearButton;
    private JButton refreshButton;

    public CustomerManagerPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        setBackground(UAAPTheme.LIGHT_SURFACE);

        add(createFormPanel(), BorderLayout.NORTH);
        add(createTablePanel(), BorderLayout.CENTER);
        add(createButtonPanel(), BorderLayout.SOUTH);

        loadCustomers();
    }

    private JPanel createFormPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(UAAPTheme.CARD_BACKGROUND);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UAAPTheme.CARD_BORDER, 2),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        // Title
        JLabel titleLabel = new JLabel("Customer Details");
        titleLabel.setFont(new Font("Segoe UI Semibold", Font.BOLD, 14));
        titleLabel.setForeground(UAAPTheme.TEXT_PRIMARY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 4;
        gbc.insets = new Insets(0, 0, 10, 0);
        panel.add(titleLabel, gbc);

        gbc.gridwidth = 1;
        gbc.insets = new Insets(5, 5, 5, 5);

        // Initialize fields
        idField = new JTextField(10);
        idField.setEditable(false);
        UAAPTheme.styleTextField(idField);

        firstNameField = new JTextField(15);
        UAAPTheme.styleTextField(firstNameField);

        lastNameField = new JTextField(15);
        UAAPTheme.styleTextField(lastNameField);

        emailField = new JTextField(20);
        UAAPTheme.styleTextField(emailField);

        phoneField = new JTextField(15);
        UAAPTheme.styleTextField(phoneField);

        organizationField = new JTextField(15);
        UAAPTheme.styleTextField(organizationField);

        preferredTeamField = new JTextField(15);
        UAAPTheme.styleTextField(preferredTeamField);

        statusCombo = new JComboBox<>(new String[]{"Active", "Inactive", "Suspended"});
        UAAPTheme.styleComboBox(statusCombo);

        paymentMethodCombo = new JComboBox<>(new String[]{"Cash", "Credit Card", "Debit Card", "GCash", "PayMaya"});
        UAAPTheme.styleComboBox(paymentMethodCombo);

        // Row 1
        addFormField(panel, 1, 0, "Customer ID:", idField);
        addFormField(panel, 1, 1, "First Name:", firstNameField);

        // Row 2
        addFormField(panel, 2, 0, "Last Name:", lastNameField);
        addFormField(panel, 2, 1, "Email:", emailField);

        // Row 3
        addFormField(panel, 3, 0, "Phone:", phoneField);
        addFormField(panel, 3, 1, "Organization:", organizationField);

        // Row 4
        addFormField(panel, 4, 0, "Preferred Team:", preferredTeamField);
        addFormField(panel, 4, 1, "Status:", statusCombo);

        // Row 5
        addFormField(panel, 5, 0, "Payment Method:", paymentMethodCombo);

        return panel;
    }

    private void addFormField(JPanel panel, int row, int col, String label, Component field) {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridy = row;

        // Label
        JLabel jLabel = new JLabel(label);
        jLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        jLabel.setForeground(UAAPTheme.TEXT_PRIMARY);
        gbc.gridx = col * 2;
        gbc.anchor = GridBagConstraints.EAST;
        panel.add(jLabel, gbc);

        // Field
        gbc.gridx = col * 2 + 1;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0.5;
        panel.add(field, gbc);
    }

    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setOpaque(false);

        JLabel titleLabel = new JLabel("Customer List");
        titleLabel.setFont(new Font("Segoe UI Semibold", Font.BOLD, 14));
        titleLabel.setForeground(UAAPTheme.TEXT_PRIMARY);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 5, 0));
        panel.add(titleLabel, BorderLayout.NORTH);

        customerTableModel = new DefaultTableModel(
            new Object[]{"ID", "First Name", "Last Name", "Email", "Phone", "Organization", "Preferred Team", "Status", "Payment Method"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        customerTable = new JTable(customerTableModel);
        UAAPTheme.styleTable(customerTable);
        customerTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Selection listener
        customerTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int row = customerTable.getSelectedRow();
                if (row >= 0) {
                    populateFormFromTable(row);
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(customerTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        UAAPTheme.elevate(scrollPane);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 15));
        panel.setBackground(UAAPTheme.LIGHT_SURFACE);
        panel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UAAPTheme.CARD_BORDER));

        addButton = new JButton("Add Customer");
        updateButton = new JButton("Update");
        deleteButton = new JButton("Delete");
        clearButton = new JButton("Clear Form");
        refreshButton = new JButton("Refresh");

        UAAPTheme.styleActionButton(addButton);
        UAAPTheme.styleActionButton(updateButton);
        UAAPTheme.styleDangerButton(deleteButton);
        UAAPTheme.styleNeutralButton(clearButton);
        UAAPTheme.styleInfoButton(refreshButton);

        addButton.addActionListener(e -> handleAdd());
        updateButton.addActionListener(e -> handleUpdate());
        deleteButton.addActionListener(e -> handleDelete());
        clearButton.addActionListener(e -> clearForm());
        refreshButton.addActionListener(e -> loadCustomers());

        panel.add(addButton);
        panel.add(updateButton);
        panel.add(deleteButton);
        panel.add(clearButton);
        panel.add(refreshButton);

        return panel;
    }

    private void populateFormFromTable(int row) {
        idField.setText(String.valueOf(customerTableModel.getValueAt(row, 0)));
        firstNameField.setText(String.valueOf(customerTableModel.getValueAt(row, 1)));
        lastNameField.setText(String.valueOf(customerTableModel.getValueAt(row, 2)));
        emailField.setText(String.valueOf(customerTableModel.getValueAt(row, 3)));
        phoneField.setText(String.valueOf(customerTableModel.getValueAt(row, 4)));
        organizationField.setText(String.valueOf(customerTableModel.getValueAt(row, 5)));
        preferredTeamField.setText(String.valueOf(customerTableModel.getValueAt(row, 6)));
        statusCombo.setSelectedItem(customerTableModel.getValueAt(row, 7));
        paymentMethodCombo.setSelectedItem(customerTableModel.getValueAt(row, 8));
    }

    private void handleAdd() {
        try {
            Customer customer = formToCustomer(false);
            customerDAO.insertCustomer(customer);
            showInfo("Customer added successfully!");
            loadCustomers();
            clearForm();
        } catch (Exception ex) {
            showError("Unable to add customer:\n" + ex.getMessage());
        }
    }

    private void handleUpdate() {
        if (idField.getText().trim().isEmpty()) {
            showError("Please select a customer first.");
            return;
        }

        try {
            Customer customer = formToCustomer(true);
            customerDAO.updateCustomer(customer);
            showInfo("Customer updated successfully!");
            loadCustomers();
        } catch (Exception ex) {
            showError("Unable to update customer:\n" + ex.getMessage());
        }
    }

    private void handleDelete() {
        if (idField.getText().trim().isEmpty()) {
            showError("Please select a customer first.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Delete selected customer?",
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION
        );
        
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            int customerId = Integer.parseInt(idField.getText().trim());
            customerDAO.deleteCustomer(customerId);
            showInfo("Customer deleted successfully!");
            loadCustomers();
            clearForm();
        } catch (Exception ex) {
            showError("Unable to delete customer:\n" + ex.getMessage());
        }
    }

    private Customer formToCustomer(boolean includeId) {
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();
        String organization = organizationField.getText().trim();
        String preferredTeam = preferredTeamField.getText().trim();
        String status = (String) statusCombo.getSelectedItem();
        String paymentMethod = (String) paymentMethodCombo.getSelectedItem();

        if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty()) {
            throw new IllegalArgumentException("First name, last name, and email are required.");
        }

        Customer customer = new Customer(
            includeId ? Integer.parseInt(idField.getText().trim()) : 0,
            firstName,
            lastName,
            phone,
            email,
            organization,
            null, // registration date will be set by DAO
            preferredTeam,
            status,
            paymentMethod
        );
        
        return customer;
    }

    private void clearForm() {
        idField.setText("");
        firstNameField.setText("");
        lastNameField.setText("");
        emailField.setText("");
        phoneField.setText("");
        organizationField.setText("");
        preferredTeamField.setText("");
        statusCombo.setSelectedIndex(0);
        paymentMethodCombo.setSelectedIndex(0);
        customerTable.clearSelection();
    }

    private void loadCustomers() {
        customerTableModel.setRowCount(0);
        try {
            var customers = customerDAO.getAllCustomers();
            for (Customer customer : customers) {
                customerTableModel.addRow(new Object[]{
                    customer.getCustomerId(),
                    customer.getFirstName(),
                    customer.getLastName(),
                    customer.getEmail(),
                    customer.getPhoneNumber(),
                    customer.getOrganization(),
                    customer.getPreferredTeam(),
                    customer.getStatus(),
                    customer.getPaymentMethod()
                });
            }
        } catch (SQLException ex) {
            showError("Unable to load customers:\n" + ex.getMessage());
        }
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void showInfo(String message) {
        JOptionPane.showMessageDialog(this, message, "Info", JOptionPane.INFORMATION_MESSAGE);
    }
}
