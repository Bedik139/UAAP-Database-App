import java.awt.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;
import javax.swing.*;
import javax.swing.text.html.*;

public class ChatbotPanel extends JPanel {
    
    private JTextPane chatArea;
    private JTextField inputField;
    private JButton sendButton;
    private Map<String, String> faqDatabase;
    private List<String> greetings;
    private List<String> farewells;
    private Random random;
    
    public ChatbotPanel() {
        random = new Random();
        initializeFAQDatabase();
        initializeGreetings();
        initializeFarewells();
        setupUI();
        displayWelcomeMessage();
    }
    
    private void initializeFAQDatabase() {
        faqDatabase = new LinkedHashMap<>();
        
        // Ticket Purchase FAQs
        faqDatabase.put("how to buy tickets|purchase tickets|buy ticket", 
            "Great question! 🎟️ To purchase tickets, simply go to the 'Purchase Ticket' tab where you can:\n" +
            "1. Select your desired event\n" +
            "2. Choose your seat type (Upper Box or Lower Box)\n" +
            "3. Enter the quantity (max 2 tickets per purchase)\n" +
            "4. Complete your customer details\n" +
            "5. Click 'Purchase' to confirm!\n\n" +
            "Your tickets will be ready instantly! Is there anything else you'd like to know?");
        
        faqDatabase.put("ticket price|how much|cost", 
            "I'd be happy to help with pricing! 💰\n\n" +
            "Ticket prices vary by seat type:\n" +
            "• Lower Box seats are typically more expensive (closer to the action!)\n" +
            "• Upper Box seats are more budget-friendly\n\n" +
            "The exact price depends on the specific event you select. You'll see the price displayed when choosing your seats in the Purchase Ticket tab.\n\n" +
            "Would you like to know about any specific event?");
        
        faqDatabase.put("refund|cancel ticket|return ticket", 
            "I understand plans can change sometimes! 😊\n\n" +
            "To refund your ticket:\n" +
            "1. Go to the 'Refund Ticket' tab\n" +
            "2. Enter your Sale ID (you received this when you purchased)\n" +
            "3. Provide a reason for the refund (optional but appreciated)\n" +
            "4. Click 'Process Refund'\n\n" +
            "⚠️ Important: Refunds are subject to the event's refund policy. You'll need your Sale ID to process the refund.\n\n" +
            "Need help finding your Sale ID?");
        
        faqDatabase.put("sale id|receipt|confirmation", 
            "Your Sale ID is your ticket confirmation number! 📋\n\n" +
            "You should have received it:\n" +
            "• Immediately after completing your purchase\n" +
            "• Displayed on the success message screen\n" +
            "• Saved in your purchase confirmation\n\n" +
            "💡 Pro tip: Always save your Sale ID! You'll need it for refunds or if you have any questions about your tickets.\n\n" +
            "Lost your Sale ID? Please contact customer support with your email and event details.");
        
        // Event Information FAQs
        faqDatabase.put("what events|available events|upcoming games", 
            "We have exciting UAAP events coming up! 🏀🏐\n\n" +
            "Current sports available:\n" +
            "• Men's Basketball - Intense playoff matches!\n" +
            "• Women's Volleyball - Championship games!\n\n" +
            "To see all available events:\n" +
            "1. Go to the 'Purchase Ticket' tab\n" +
            "2. Click on the Event dropdown menu\n" +
            "3. Browse through all upcoming games\n\n" +
            "Each event shows the date, time, and venue. Which sport interests you most?");
        
        faqDatabase.put("venue|stadium|location|where", 
            "Great question about venues! 📍\n\n" +
            "UAAP games are held at various premier venues:\n" +
            "• MOA Arena - Main basketball venue\n" +
            "• Smart Araneta Coliseum - Historic venue for major games\n" +
            "• FilOil EcoOil Centre - Volleyball matches\n" +
            "• And more partner venues!\n\n" +
            "The specific venue is shown when you select an event in the Purchase Ticket tab. Each venue has different seating capacities and sections.\n\n" +
            "Looking for a specific venue?");
        
        faqDatabase.put("seat type|seat difference|seating", 
            "Let me explain our seating options! 💺\n\n" +
            "We offer two main seat types:\n\n" +
            "🎯 Lower Box:\n" +
            "• Closer to the court/playing area\n" +
            "• Premium view of the action\n" +
            "• Higher price point\n" +
            "• Limited availability\n\n" +
            "👁️ Upper Box:\n" +
            "• Elevated view of the entire venue\n" +
            "• Great overall perspective\n" +
            "• More affordable option\n" +
            "• More seats available\n\n" +
            "Both offer excellent views and an amazing atmosphere! Which would you prefer?");
        
        // Teams & Players FAQs
        faqDatabase.put("teams|schools|universities", 
            "The UAAP features the best collegiate teams in the Philippines! 🏆\n\n" +
            "Member universities:\n" +
            "• Ateneo Blue Eagles\n" +
            "• De La Salle Green Archers\n" +
            "• UP Fighting Maroons\n" +
            "• UST Growling Tigers\n" +
            "• FEU Tamaraws\n" +
            "• UE Red Warriors\n" +
            "• NU Bulldogs\n" +
            "• Adamson Soaring Falcons\n\n" +
            "Each school has rich traditions and passionate fans! Do you have a favorite team? 🎓");
        
        faqDatabase.put("schedule|when|game time|match time", 
            "To check game schedules: 📅\n\n" +
            "1. Visit the 'Purchase Ticket' tab\n" +
            "2. Browse the Event dropdown\n" +
            "3. Each event shows:\n" +
            "   - Date and time\n" +
            "   - Competing teams\n" +
            "   - Venue location\n\n" +
            "Games are typically held on weekends and weekday afternoons/evenings.\n\n" +
            "Looking for a specific matchup? Let me know!");
        
        // Technical Support FAQs
        faqDatabase.put("problem|error|not working|bug", 
            "Oh no! I'm sorry you're experiencing issues! 😟\n\n" +
            "Let me help troubleshoot:\n\n" +
            "1. Make sure all required fields are filled out\n" +
            "2. Check that your Sale ID is entered correctly (numbers only)\n" +
            "3. Verify you have a stable internet connection\n" +
            "4. Try refreshing the page\n\n" +
            "If the problem persists:\n" +
            "• Take note of any error messages\n" +
            "• Try restarting the application\n" +
            "• Contact technical support with details\n\n" +
            "What specific issue are you encountering? I'm here to help! 💪");
        
        faqDatabase.put("contact|support|help|customer service", 
            "I'm here to help, but if you need further assistance: 📞\n\n" +
            "Customer Support Options:\n" +
            "• Email: support@uaap-ticketing.ph\n" +
            "• Hotline: 1-800-UAAP-TIX\n" +
            "• Live Chat: Available 9 AM - 5 PM (Mon-Fri)\n" +
            "• Social Media: @UAAPTicketing\n\n" +
            "Our support team typically responds within 24 hours. For urgent concerns, calling the hotline is fastest!\n\n" +
            "Can I help with anything else right now?");
        
        faqDatabase.put("maximum tickets|ticket limit|how many", 
            "Good question about ticket limits! 🎫\n\n" +
            "Per transaction, you can purchase:\n" +
            "• Maximum: 2 tickets\n" +
            "• Minimum: 1 ticket\n\n" +
            "This helps ensure fair access for all fans! 🤝\n\n" +
            "If you need more tickets:\n" +
            "• Make multiple separate purchases\n" +
            "• Each purchase requires a new transaction\n" +
            "• You'll receive separate Sale IDs\n\n" +
            "Planning to bring friends? That's the spirit!");
        
        faqDatabase.put("payment|pay|payment method", 
            "Regarding payment methods: 💳\n\n" +
            "Currently, our system processes payments through our secure platform. When you click 'Purchase' after selecting your tickets, the payment will be processed.\n\n" +
            "✅ What you need:\n" +
            "• Valid customer information\n" +
            "• Event and seat selection\n" +
            "• Quantity (1-2 tickets)\n\n" +
            "The system will securely handle your transaction and provide immediate confirmation with your Sale ID.\n\n" +
            "Ready to purchase your tickets?");
        
        faqDatabase.put("age|children|kids|senior", 
            "Great question about age requirements! 👶👴\n\n" +
            "• All ages welcome at UAAP events!\n" +
            "• Children typically require their own ticket (venue policy)\n" +
            "• Senior citizens and PWDs may have special discounts\n" +
            "• Please bring valid IDs for age verification if needed\n\n" +
            "UAAP games are family-friendly events perfect for everyone to enjoy! 👨‍👩‍👧‍👦\n\n" +
            "Planning to bring the whole family?");
    }
    
    private void initializeGreetings() {
        greetings = Arrays.asList(
            "Hello! Welcome to the UAAP Ticketing Assistant! 👋 How can I help you today?",
            "Hi there! Great to see you! 😊 What can I assist you with?",
            "Hey! Welcome! I'm here to answer all your UAAP ticketing questions! 🎟️",
            "Hello friend! Ready to cheer for your favorite team? Let me help you out! 🏀",
            "Hi! Welcome to UAAP! What would you like to know? 🏐"
        );
    }
    
    private void initializeFarewells() {
        farewells = Arrays.asList(
            "You're very welcome! Enjoy the game! 🎉 Go UAAP! 🏆",
            "Happy to help! Have an amazing time at the event! 🌟",
            "My pleasure! Hope you have a fantastic experience! 🎊",
            "Glad I could assist! See you at the games! 👋",
            "Anytime! Enjoy the UAAP spirit! 💚💙"
        );
    }
    
    private void setupUI() {
        setLayout(new BorderLayout(15, 15));
        setBackground(UAAPTheme.LIGHT_SURFACE);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Header Panel
        JPanel headerPanel = createHeaderPanel();
        add(headerPanel, BorderLayout.NORTH);
        
        // Chat Display Area
        chatArea = new JTextPane();
        chatArea.setEditable(false);
        chatArea.setContentType("text/html");
        
        // Use a font that supports emojis better
        Font chatFont = new Font("Segoe UI", Font.PLAIN, 14);
        chatArea.setFont(chatFont);
        chatArea.setBackground(UAAPTheme.CARD_BACKGROUND);
        chatArea.setForeground(UAAPTheme.TEXT_PRIMARY);
        chatArea.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Initialize with empty HTML document
        chatArea.setText("<html><body style='font-family: Segoe UI, Arial, sans-serif; font-size: 13px; color: #2C3E50; background-color: #F8F9FA; padding: 10px;'></body></html>");
        
        JScrollPane scrollPane = new JScrollPane(chatArea);
        scrollPane.setBackground(UAAPTheme.CARD_BACKGROUND);
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UAAPTheme.PRIMARY_GREEN, 2),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        add(scrollPane, BorderLayout.CENTER);
        
        // Input Panel
        JPanel inputPanel = createInputPanel();
        add(inputPanel, BorderLayout.SOUTH);
        
        // Quick Questions Panel
        JPanel quickQuestionsPanel = createQuickQuestionsPanel();
        add(quickQuestionsPanel, BorderLayout.EAST);
    }
    
    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setOpaque(false);
        
        JLabel titleLabel = new JLabel("UAAP Ticketing Assistant");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(UAAPTheme.PRIMARY_GREEN);
        
        JLabel subtitleLabel = new JLabel("Ask me anything about tickets, events, or the UAAP!");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitleLabel.setForeground(UAAPTheme.TEXT_SECONDARY);
        
        JPanel textPanel = new JPanel(new BorderLayout());
        textPanel.setOpaque(false);
        textPanel.add(titleLabel, BorderLayout.NORTH);
        textPanel.add(subtitleLabel, BorderLayout.CENTER);
        
        panel.add(textPanel, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createInputPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 0, 0, 0));
        
        inputField = new JTextField();
        inputField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        UAAPTheme.styleTextField(inputField);
        inputField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UAAPTheme.CARD_BORDER, 2),
            BorderFactory.createEmptyBorder(10, 12, 10, 12)
        ));
        inputField.addActionListener(e -> sendMessage());
        
        sendButton = new JButton("Send");
        UAAPTheme.styleActionButton(sendButton);
        sendButton.setPreferredSize(new Dimension(100, 45));
        sendButton.addActionListener(e -> sendMessage());
        
        JButton clearButton = new JButton("Clear");
        UAAPTheme.styleNeutralButton(clearButton);
        clearButton.setPreferredSize(new Dimension(100, 45));
        clearButton.addActionListener(e -> clearChat());
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.add(clearButton);
        buttonPanel.add(sendButton);
        
        panel.add(inputField, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.EAST);
        
        return panel;
    }
    
    private JPanel createQuickQuestionsPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UAAPTheme.CARD_BORDER, 2),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        panel.setPreferredSize(new Dimension(250, 0));
        
        JLabel titleLabel = new JLabel("Quick Questions");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        titleLabel.setForeground(UAAPTheme.PRIMARY_GREEN);
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(titleLabel);
        
        panel.add(Box.createVerticalStrut(15));
        
        String[] quickQuestions = {
            "How to buy tickets?",
            "What events are available?",
            "How much do tickets cost?",
            "How to refund a ticket?",
            "What are the seat types?",
            "Where is the venue?",
            "What is the ticket limit?",
            "How to contact support?"
        };
        
        for (String question : quickQuestions) {
            JButton btn = new JButton("<html><div style='text-align: left;'>" + question + "</div></html>");
            btn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            btn.setAlignmentX(Component.LEFT_ALIGNMENT);
            btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            btn.setBackground(UAAPTheme.CARD_BACKGROUND);
            btn.setForeground(UAAPTheme.TEXT_PRIMARY);
            btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UAAPTheme.PRIMARY_GREEN, 1),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)
            ));
            btn.setFocusPainted(false);
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btn.setOpaque(true);
            btn.setContentAreaFilled(true);
            
            // Add hover effect
            btn.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseEntered(java.awt.event.MouseEvent e) {
                    btn.setBackground(UAAPTheme.HOVER_BG);
                }
                
                @Override
                public void mouseExited(java.awt.event.MouseEvent e) {
                    btn.setBackground(UAAPTheme.CARD_BACKGROUND);
                }
            });
            
            btn.addActionListener(e -> {
                inputField.setText(question);
                sendMessage();
            });
            panel.add(btn);
            panel.add(Box.createVerticalStrut(8));
        }
        
        return panel;
    }
    
    private void displayWelcomeMessage() {
        String timeGreeting = getTimeBasedGreeting();
        appendToChatArea("Bot", timeGreeting + "\n\n" + 
            "I'm your friendly UAAP ticketing assistant! I can help you with:\n" +
            "• Purchasing tickets 🎟️\n" +
            "• Event information 📅\n" +
            "• Refund procedures 💰\n" +
            "• Seating options 💺\n" +
            "• And much more!\n\n" +
            "Feel free to type your question or click one of the quick questions on the right! 👉\n" +
            "────────────────────────────────────");
    }
    
    private String getTimeBasedGreeting() {
        LocalTime now = LocalTime.now();
        if (now.isBefore(LocalTime.NOON)) {
            return "Good morning! ☀️";
        } else if (now.isBefore(LocalTime.of(18, 0))) {
            return "Good afternoon! 🌤️";
        } else {
            return "Good evening! 🌙";
        }
    }
    
    private void sendMessage() {
        String userInput = inputField.getText().trim();
        if (userInput.isEmpty()) {
            return;
        }
        
        appendToChatArea("You", userInput);
        inputField.setText("");
        
        // Get bot response
        String response = generateResponse(userInput.toLowerCase());
        appendToChatArea("Bot", response);
    }
    
    private String generateResponse(String input) {
        // Check for greetings
        if (input.matches(".*(hi|hello|hey|greetings|good morning|good afternoon|good evening).*")) {
            return greetings.get(random.nextInt(greetings.size()));
        }
        
        // Check for thanks
        if (input.matches(".*(thank|thanks|appreciate|grateful).*")) {
            return farewells.get(random.nextInt(farewells.size()));
        }
        
        // Check for goodbye
        if (input.matches(".*(bye|goodbye|see you|exit|quit).*")) {
            return "Goodbye! Thanks for chatting with me! Come back anytime! 👋😊";
        }
        
        // Search FAQ database
        for (Map.Entry<String, String> entry : faqDatabase.entrySet()) {
            String[] keywords = entry.getKey().split("\\|");
            for (String keyword : keywords) {
                if (input.contains(keyword.trim())) {
                    return entry.getValue();
                }
            }
        }
        
        // If no match found, provide helpful error response
        return getNoMatchResponse(input);
    }
    
    private String getNoMatchResponse(String input) {
        List<String> friendlyResponses = Arrays.asList(
            "Hmm, I'm not quite sure about that one! 🤔\n\n" +
            "Could you rephrase your question? I'm great with topics like:\n" +
            "• Ticket purchasing\n" +
            "• Refunds and cancellations\n" +
            "• Event schedules\n" +
            "• Venue information\n" +
            "• Seating options\n\n" +
            "Try clicking one of the quick questions on the right, or ask me something specific! 💡",
            
            "Interesting question! Unfortunately, I don't have information about that. 😅\n\n" +
            "I specialize in helping with:\n" +
            "• How to buy tickets 🎟️\n" +
            "• Upcoming UAAP events 🏀🏐\n" +
            "• Ticket refunds and policies 💰\n" +
            "• Venue and seating details 📍\n\n" +
            "What else would you like to know about these topics?",
            
            "I wish I could help with that, but I'm not sure! 🙈\n\n" +
            "My expertise is in UAAP ticketing! I can assist you with:\n" +
            "✓ Purchasing process\n" +
            "✓ Event information\n" +
            "✓ Refund procedures\n" +
            "✓ Seating arrangements\n" +
            "✓ Contact information\n\n" +
            "Try asking about one of these topics, and I'll do my best to help! 😊",
            
            "Oops! I didn't catch that. Let me help you better! 🎯\n\n" +
            "I'm your go-to bot for:\n" +
            "📱 Ticket purchasing steps\n" +
            "🎪 Available events and schedules\n" +
            "↩️ Refund and cancellation help\n" +
            "🪑 Seat type differences\n" +
            "🏟️ Venue locations\n\n" +
            "Click a quick question on the side or type something about these topics!"
        );
        
        return friendlyResponses.get(random.nextInt(friendlyResponses.size()));
    }
    
    private void appendToChatArea(String sender, String message) {
        String timestamp = LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm a"));
        
        // Determine colors based on sender
        String bgColor = sender.equals("You") ? "#E3F2FD" : "#F1F8F4";
        String textColor = sender.equals("You") ? "#1565C0" : "#2E7D32";
        String senderIcon = sender.equals("You") ? "&#x1F64B;" : "&#x1F916;"; // Unicode HTML entities for emojis
        
        // Build HTML content
        try {
            HTMLDocument doc = (HTMLDocument) chatArea.getDocument();
            HTMLEditorKit kit = (HTMLEditorKit) chatArea.getEditorKit();
            
            // Format message with proper line breaks
            String formattedMessage = message.replace("\n", "<br>");
            
            String htmlContent = String.format(
                "<div style='background-color: %s; padding: 12px; margin: 8px 0; border-radius: 8px; border-left: 4px solid %s;'>" +
                "<div style='color: %s; font-weight: bold; margin-bottom: 5px;'>" +
                "%s %s <span style='font-size: 11px; font-weight: normal; color: #666;'>[%s]</span>" +
                "</div>" +
                "<div style='color: #2C3E50; line-height: 1.5;'>%s</div>" +
                "</div>",
                bgColor, textColor, textColor, senderIcon, sender, timestamp, formattedMessage
            );
            
            kit.insertHTML(doc, doc.getLength(), htmlContent, 0, 0, null);
            
            // Auto-scroll to bottom
            chatArea.setCaretPosition(doc.getLength());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void clearChat() {
        chatArea.setText("<html><body style='font-family: Segoe UI, Arial, sans-serif; font-size: 13px; color: #2C3E50; background-color: #F8F9FA; padding: 10px;'></body></html>");
        displayWelcomeMessage();
    }
}
