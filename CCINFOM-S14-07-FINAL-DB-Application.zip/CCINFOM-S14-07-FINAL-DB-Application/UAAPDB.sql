DROP DATABASE IF EXISTS UAAPDBSQL;
CREATE DATABASE UAAPDBSQL;
USE UAAPDBSQL;

CREATE TABLE event (
  event_id          INT           NOT NULL AUTO_INCREMENT,
  event_name        VARCHAR(120)  NOT NULL,
  sport             ENUM('Basketball','Volleyball') NOT NULL,
  event_date        DATE          NOT NULL,
  event_time_start  TIME          NOT NULL,
  event_time_end    TIME          NOT NULL,
  venue_address     ENUM('Mall of Asia Arena','Smart Araneta Coliseum','PhilSports Arena','Ynares Center','Filoil EcoOil Centre')  NOT NULL,
  venue_capacity    INT           NOT NULL,
  event_status      ENUM('Scheduled','Active','Completed','Cancelled') NOT NULL DEFAULT 'Scheduled',
  PRIMARY KEY (event_id)
) AUTO_INCREMENT=1000;

CREATE TABLE team (
  team_id             INT          NOT NULL AUTO_INCREMENT,
  team_name           ENUM(
                          'De La Salle Green Archers',
                          'Ateneo Blue Eagles',
                          'UP Fighting Maroons',
                          'UST Growling Tigers',
                          'Far Eastern University Tamaraws',
                          'University of the East Red Warriors',
                          'National University Bulldogs',
                          'Adamson Soaring Falcons',
                          'De La Salle Lady Archers',
                          'Ateneo Blue Eagles (Women)',
                          'UP Lady Maroons',
                          'UST Golden Tigresses',
                          'FEU Lady Tamaraws',
                          'UE Lady Warriors',
                          'NU Lady Bulldogs',
                          'Adamson Lady Falcons'
                        ) NOT NULL,
  gender              ENUM('Men','Women') NOT NULL,
  sport               ENUM('Basketball','Volleyball') NOT NULL,
  seasons_played      INT          NOT NULL DEFAULT 0,
  standing_wins       INT          NOT NULL DEFAULT 0,
  standing_losses     INT          NOT NULL DEFAULT 0,
  total_games_played  INT          NOT NULL DEFAULT 0,
  PRIMARY KEY (team_id),
  UNIQUE KEY uq_team_name_gender_sport (team_name, gender, sport)
) AUTO_INCREMENT=1000;

CREATE TABLE player (
  player_id         INT          NOT NULL AUTO_INCREMENT,
  team_id           INT          NOT NULL,
  player_first_name VARCHAR(60)  NOT NULL,
  player_last_name  VARCHAR(60)  NOT NULL,
  player_number     INT          NOT NULL,
  player_sport      ENUM('Basketball','Volleyball') NOT NULL,
  age               INT,
  position          VARCHAR(30),
  weight            DECIMAL(5,2),
  height            DECIMAL(5,2),
  individual_score  INT          NOT NULL DEFAULT 0,
  PRIMARY KEY (player_id),
  KEY idx_player_team (team_id),
  KEY idx_player_sport (player_sport),
  CONSTRAINT fk_player_team
    FOREIGN KEY (team_id) REFERENCES team(team_id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) AUTO_INCREMENT=1000;

CREATE TABLE `match` (
  match_id         INT          NOT NULL AUTO_INCREMENT,
  event_id         INT          NOT NULL,
  match_type       ENUM('Elimination_Round','Semifinals','Finals') NOT NULL,
  match_time_start TIME         NOT NULL,
  match_time_end   TIME         NOT NULL,
  status           ENUM('Scheduled','Completed','Cancelled','Postponed') NOT NULL DEFAULT 'Scheduled',
  score_summary    VARCHAR(255),
  PRIMARY KEY (match_id),
  KEY idx_match_event (event_id),
  CONSTRAINT fk_match_event
    FOREIGN KEY (event_id) REFERENCES event(event_id)
    ON DELETE CASCADE ON UPDATE CASCADE
) AUTO_INCREMENT=1000;

CREATE TABLE match_team (
  match_id    INT       NOT NULL,
  team_id     INT       NOT NULL,
  is_home     BOOLEAN   NOT NULL,
  team_score  INT       NOT NULL DEFAULT 0,
  PRIMARY KEY (match_id,team_id),
  KEY idx_mt_team (team_id),
  CONSTRAINT fk_mt_match
    FOREIGN KEY (match_id) REFERENCES `match`(match_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_mt_team
    FOREIGN KEY (team_id) REFERENCES team(team_id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT ck_mt_is_home CHECK (is_home IN (0,1))
);

CREATE TABLE match_quarter_score (
  match_id    INT NOT NULL,
  team_id     INT NOT NULL,
  quarter_no  INT NOT NULL,
  quarter_points INT NOT NULL,
  PRIMARY KEY (match_id,team_id,quarter_no),
  KEY idx_mqs_team (team_id),
  CONSTRAINT fk_mqs_match
    FOREIGN KEY (match_id) REFERENCES `match`(match_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_mqs_team
    FOREIGN KEY (team_id) REFERENCES team(team_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT ck_quarter_range CHECK (quarter_no BETWEEN 1 AND 4)
);

CREATE TABLE match_set_score (
  match_id   INT NOT NULL,
  team_id    INT NOT NULL,
  set_no     INT NOT NULL,
  set_points INT NOT NULL,
  PRIMARY KEY (match_id,team_id,set_no),
  KEY idx_mss_team (team_id),
  CONSTRAINT fk_mss_match
    FOREIGN KEY (match_id) REFERENCES `match`(match_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_mss_team
    FOREIGN KEY (team_id) REFERENCES team(team_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT ck_set_range CHECK (set_no BETWEEN 1 AND 5)
);

CREATE TABLE ticket (
  ticket_id     INT            NOT NULL AUTO_INCREMENT,
  ticket_type   VARCHAR(50)    NOT NULL,
  default_price DECIMAL(10,2)  NOT NULL,
  price         DECIMAL(10,2)  NULL,
  ticket_status ENUM('Active','Inactive','Archived') NOT NULL DEFAULT 'Active',
  PRIMARY KEY (ticket_id)
) AUTO_INCREMENT=1000;

CREATE TABLE customer (
  customer_id          INT          NOT NULL AUTO_INCREMENT,
  customer_first_name  VARCHAR(60)  NOT NULL,
  customer_last_name   VARCHAR(60)  NOT NULL,
  phone_number         VARCHAR(30),
  email                VARCHAR(120),
  organization         VARCHAR(120),
  registration_date    DATE         NOT NULL DEFAULT (CURRENT_DATE),
  preferred_team       ENUM(
                          'De La Salle Green Archers',
                          'Ateneo Blue Eagles',
                          'UP Fighting Maroons',
                          'UST Growling Tigers',
                          'Far Eastern University Tamaraws',
                          'University of the East Red Warriors',
                          'National University Bulldogs',
                          'Adamson Soaring Falcons'
                        ) DEFAULT NULL,
  customer_status      VARCHAR(20),
  payment_method       VARCHAR(30),
  CONSTRAINT ck_customer_contact CHECK (
          (phone_number IS NOT NULL AND phone_number <> '')
       OR (email IS NOT NULL AND email <> '')
  ),
  PRIMARY KEY (customer_id),
  UNIQUE KEY uq_customer_email (email)
) AUTO_INCREMENT=1000;

CREATE TABLE seat (
  seat_id        INT          NOT NULL AUTO_INCREMENT,
  seat_type      VARCHAR(30)  NOT NULL,
  venue_address  ENUM('Mall of Asia Arena','Smart Araneta Coliseum','PhilSports Arena','Ynares Center','Filoil EcoOil Centre') NOT NULL,
  seat_status    ENUM('Available','OnHold','Sold') NOT NULL DEFAULT 'Available',
  ticket_id      INT          NOT NULL,
  PRIMARY KEY (seat_id),
  KEY idx_seat_venue (venue_address),
  KEY idx_seat_ticket (ticket_id),
  CONSTRAINT fk_seat_ticket
    FOREIGN KEY (ticket_id) REFERENCES ticket(ticket_id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) AUTO_INCREMENT=1000;

CREATE TABLE seat_and_ticket (
  seat_and_ticket_rec_id INT           NOT NULL AUTO_INCREMENT,
  seat_id                INT           NOT NULL,
  event_id               INT           NOT NULL,
  customer_id            INT           NOT NULL,
  sale_datetime          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  quantity               INT           NOT NULL DEFAULT 1,
  unit_price             DECIMAL(10,2) NOT NULL,
  total_price            DECIMAL(12,2) GENERATED ALWAYS AS (quantity * unit_price) STORED,
  ticket_id              INT           NOT NULL,
  match_id               INT           NULL,
  sale_status            ENUM('Sold','Refunded') NOT NULL DEFAULT 'Sold',
  PRIMARY KEY (seat_and_ticket_rec_id),
  UNIQUE KEY uq_event_seat (event_id, seat_id),
  KEY idx_sat_seat (seat_id),
  KEY idx_sat_event (event_id),
  KEY idx_sat_customer (customer_id),
  KEY idx_sat_ticket (ticket_id),
  KEY idx_sat_match (match_id),
  CONSTRAINT fk_sat_seat
    FOREIGN KEY (seat_id) REFERENCES seat(seat_id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_sat_event
    FOREIGN KEY (event_id) REFERENCES event(event_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_sat_customer
    FOREIGN KEY (customer_id) REFERENCES customer(customer_id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_sat_ticket
    FOREIGN KEY (ticket_id) REFERENCES ticket(ticket_id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_sat_match
    FOREIGN KEY (match_id) REFERENCES `match`(match_id)
    ON DELETE CASCADE ON UPDATE CASCADE
) AUTO_INCREMENT=1000;

CREATE TABLE ticket_refund_audit (
  audit_id                INT           NOT NULL AUTO_INCREMENT,
  seat_and_ticket_rec_id  INT           NOT NULL,
  refund_amount           DECIMAL(10,2) NOT NULL,
  refund_datetime         TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  reason                  VARCHAR(255),
  processed_by            VARCHAR(120),
  PRIMARY KEY (audit_id),
  KEY idx_refund_sale (seat_and_ticket_rec_id),
  KEY idx_refund_datetime (refund_datetime),
  CONSTRAINT fk_refund_sale
    FOREIGN KEY (seat_and_ticket_rec_id) REFERENCES seat_and_ticket(seat_and_ticket_rec_id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) AUTO_INCREMENT=1000;

CREATE TABLE event_personnel (
  personnel_id          INT          NOT NULL AUTO_INCREMENT,
  personnel_first_name  VARCHAR(60)  NOT NULL,
  personnel_last_name   VARCHAR(60)  NOT NULL,
  availability_status   VARCHAR(30),
  role                  ENUM(
                            'Usher','Ticketing Agent','Security',
                            'Referee','Scorekeeper','Stat Crew',
                            'Band Member','Cheerleader','Dance Troupe',
                            'Singer','Host','Halftime Entertainment'
                           ) NOT NULL,
  affiliation           VARCHAR(120) NOT NULL,
  contact_no            VARCHAR(40),
  event_id              INT          NOT NULL,
  match_id              INT          NOT NULL,
  PRIMARY KEY (personnel_id),
  KEY idx_ep_event (event_id),
  KEY idx_ep_match (match_id),
  CONSTRAINT fk_ep_event
    FOREIGN KEY (event_id) REFERENCES event(event_id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_ep_match
    FOREIGN KEY (match_id) REFERENCES `match`(match_id)
    ON DELETE CASCADE ON UPDATE CASCADE
) AUTO_INCREMENT=1000;

-- ========== DATA POPULATION ==========

-- Teams (Men's Basketball)
INSERT INTO team (team_name, gender, sport, seasons_played, standing_wins, standing_losses, total_games_played)
VALUES
('De La Salle Green Archers', 'Men', 'Basketball', 15, 12, 3, 15),
('Ateneo Blue Eagles', 'Men', 'Basketball', 15, 11, 4, 15),
('UP Fighting Maroons', 'Men', 'Basketball', 15, 10, 5, 15),
('UST Growling Tigers', 'Men', 'Basketball', 15, 7, 8, 15),
('Far Eastern University Tamaraws', 'Men', 'Basketball', 15, 8, 7, 15),
('University of the East Red Warriors', 'Men', 'Basketball', 15, 4, 11, 15),
('National University Bulldogs', 'Men', 'Basketball', 15, 9, 6, 15),
('Adamson Soaring Falcons', 'Men', 'Basketball', 15, 5, 10, 15),
-- Women's Volleyball
('De La Salle Lady Archers', 'Women', 'Volleyball', 15, 13, 2, 15),
('Ateneo Blue Eagles (Women)', 'Women', 'Volleyball', 15, 12, 3, 15),
('UP Lady Maroons', 'Women', 'Volleyball', 15, 10, 5, 15),
('UST Golden Tigresses', 'Women', 'Volleyball', 15, 11, 4, 15),
('FEU Lady Tamaraws', 'Women', 'Volleyball', 15, 7, 8, 15),
('UE Lady Warriors', 'Women', 'Volleyball', 15, 3, 12, 15),
('NU Lady Bulldogs', 'Women', 'Volleyball', 15, 9, 6, 15),
('Adamson Lady Falcons', 'Women', 'Volleyball', 15, 5, 10, 15);

-- Events (10 datasets)
INSERT INTO event (event_name, sport, event_date, event_time_start, event_time_end, venue_address, venue_capacity, event_status)
VALUES
('UAAP S87 Men''s Basketball - Opening Day', 'Basketball', '2025-11-15', '14:00:00', '18:30:00', 'Mall of Asia Arena', 15000, 'Completed'),
('UAAP S87 Men''s Basketball - Round 1 Week 2', 'Basketball', '2025-11-20', '16:00:00', '18:00:00', 'Smart Araneta Coliseum', 16000, 'Completed'),
('UAAP S87 Men''s Basketball - Round 1 Week 3', 'Basketball', '2025-11-25', '18:00:00', '20:00:00', 'PhilSports Arena', 8000, 'Completed'),
('UAAP S87 Men''s Basketball - Semifinals', 'Basketball', '2025-12-15', '18:00:00', '20:30:00', 'Smart Araneta Coliseum', 16000, 'Scheduled'),
('UAAP S87 Men''s Basketball - Finals', 'Basketball', '2026-01-10', '18:00:00', '21:00:00', 'Mall of Asia Arena', 15000, 'Scheduled'),
('UAAP S87 Women''s Volleyball - Opening Day', 'Volleyball', '2025-11-18', '14:00:00', '17:00:00', 'Mall of Asia Arena', 15000, 'Completed'),
('UAAP S87 Women''s Volleyball - Round 1 Week 2', 'Volleyball', '2025-11-22', '14:00:00', '17:00:00', 'Smart Araneta Coliseum', 16000, 'Completed'),
('UAAP S87 Women''s Volleyball - Semifinals', 'Volleyball', '2025-12-20', '14:00:00', '18:00:00', 'Mall of Asia Arena', 15000, 'Scheduled'),
('UAAP S87 Men''s Basketball - Round 1 Week 4', 'Basketball', '2025-11-28', '16:00:00', '20:00:00', 'Ynares Center', 10000, 'Completed'),
('UAAP S87 Women''s Volleyball - Finals', 'Volleyball', '2026-01-15', '14:00:00', '18:00:00', 'Filoil EcoOil Centre', 8000, 'Scheduled');

-- Players (Basketball - 5 per team, Volleyball - 6 per team)
INSERT INTO player (team_id, player_first_name, player_last_name, player_number, player_sport, age, position, weight, height, individual_score)
VALUES
-- DLSU Basketball (5 players)
(1000, 'Kevin', 'Quiambao', 5, 'Basketball', 22, 'SF', 88.0, 1.98, 285),
(1000, 'Evan', 'Nelle', 8, 'Basketball', 23, 'PG', 78.0, 1.85, 245),
(1000, 'Michael', 'Phillips', 15, 'Basketball', 24, 'PF', 92.0, 2.01, 198),
(1000, 'Joshua', 'David', 12, 'Basketball', 21, 'SG', 75.0, 1.83, 167),
(1000, 'Mark', 'Nonoy', 20, 'Basketball', 22, 'C', 95.0, 2.00, 156),
-- Ateneo Basketball (5 players)
(1001, 'Forthsky', 'Padrigao', 11, 'Basketball', 22, 'SG', 75.0, 1.82, 267),
(1001, 'Kai', 'Ballungay', 4, 'Basketball', 24, 'PF', 92.0, 2.03, 243),
(1001, 'Chris', 'Koon', 33, 'Basketball', 23, 'C', 98.0, 2.05, 189),
(1001, 'Sean', 'Quitevis', 7, 'Basketball', 21, 'PG', 74.0, 1.81, 156),
(1001, 'Jared', 'Bahay', 14, 'Basketball', 22, 'SF', 81.0, 1.90, 178),
-- UP Basketball (5 players)
(1002, 'Carl', 'Tamayo', 33, 'Basketball', 23, 'PF', 95.0, 2.05, 256),
(1002, 'Malick', 'Diouf', 11, 'Basketball', 22, 'C', 102.0, 2.08, 234),
(1002, 'Francis', 'Lopez', 7, 'Basketball', 24, 'SG', 77.0, 1.85, 198),
(1002, 'Terrence', 'Fortea', 8, 'Basketball', 21, 'PG', 73.0, 1.80, 167),
(1002, 'Aldous', 'Torculas', 10, 'Basketball', 23, 'SF', 85.0, 1.92, 145),
-- UST Basketball (5 players)
(1003, 'Soulemane', 'Chabi Yo', 15, 'Basketball', 25, 'C', 100.0, 2.01, 223),
(1003, 'Nic', 'Cabanero', 12, 'Basketball', 23, 'PG', 76.0, 1.83, 189),
(1003, 'Christian', 'Manaytay', 7, 'Basketball', 22, 'SF', 88.0, 1.95, 167),
(1003, 'Royce', 'Mantua', 24, 'Basketball', 21, 'SG', 75.0, 1.81, 145),
(1003, 'Paul', 'Manalang', 21, 'Basketball', 22, 'PF', 90.0, 1.98, 134),
-- FEU Basketball (5 players)
(1004, 'Royce', 'Alforque', 11, 'Basketball', 23, 'PG', 77.0, 1.84, 234),
(1004, 'Mo', 'Konateh', 33, 'Basketball', 24, 'C', 99.0, 2.04, 212),
(1004, 'Veejay', 'Pre', 5, 'Basketball', 22, 'SF', 87.0, 1.96, 178),
(1004, 'Jilson', 'Bautista', 7, 'Basketball', 21, 'SG', 74.0, 1.82, 156),
(1004, 'Patrick', 'Sleat', 4, 'Basketball', 23, 'PF', 91.0, 2.00, 145),
-- UE Basketball (5 players)
(1005, 'Precious', 'Momowei', 14, 'Basketball', 24, 'C', 101.0, 2.06, 198),
(1005, 'Ethan', 'Galang', 7, 'Basketball', 22, 'SG', 76.0, 1.83, 167),
(1005, 'Kyle', 'Paranada', 11, 'Basketball', 21, 'SF', 86.0, 1.95, 145),
(1005, 'Wello', 'Lingolingo', 5, 'Basketball', 23, 'PG', 73.0, 1.80, 123),
(1005, 'Rey', 'Remogat', 9, 'Basketball', 22, 'PF', 89.0, 1.97, 112),
-- NU Basketball (5 players)
(1006, 'Steve', 'Nash', 11, 'Basketball', 23, 'PG', 78.0, 1.86, 245),
(1006, 'Jake', 'Figueroa', 22, 'Basketball', 24, 'PF', 93.0, 2.00, 223),
(1006, 'PJ', 'Palacielo', 7, 'Basketball', 22, 'C', 97.0, 2.03, 189),
(1006, 'Kenshin', 'Padilla', 15, 'Basketball', 21, 'SG', 75.0, 1.82, 167),
(1006, 'Jake', 'Palaganas', 3, 'Basketball', 22, 'SF', 84.0, 1.93, 156),
-- Adamson Basketball (5 players)
(1007, 'Matty', 'Erolon', 7, 'Basketball', 22, 'PG', 77.0, 1.84, 212),
(1007, 'Matthew', 'Montebon', 23, 'Basketball', 23, 'SF', 90.0, 1.98, 189),
(1007, 'Didat', 'Hanapi', 11, 'Basketball', 24, 'C', 96.0, 2.02, 167),
(1007, 'Joshua', 'Barcelona', 5, 'Basketball', 21, 'SG', 74.0, 1.81, 145),
(1007, 'Joem', 'Sabandal', 13, 'Basketball', 23, 'PF', 88.0, 1.96, 134),
-- DLSU Lady Archers Volleyball (6 players) - team_id 1008
(1008, 'Angel', 'Canino', 1, 'Volleyball', 21, 'S', 60.0, 1.75, 145),
(1008, 'Leila', 'Cruz', 3, 'Volleyball', 22, 'OH', 65.0, 1.80, 178),
(1008, 'Julia', 'Coronel', 9, 'Volleyball', 20, 'MB', 68.0, 1.85, 134),
(1008, 'Thea', 'Gagate', 14, 'Volleyball', 21, 'OH', 64.0, 1.78, 123),
(1008, 'Baby Love', 'Barbon', 7, 'Volleyball', 22, 'MB', 67.0, 1.84, 112),
(1008, 'Justine', 'Jazareno', 4, 'Volleyball', 20, 'L', 58.0, 1.68, 98),
-- Ateneo Blue Eagles (Women) Volleyball (6 players) - team_id 1009
(1009, 'Jhoana', 'Maraguinot', 2, 'Volleyball', 23, 'S', 61.0, 1.76, 156),
(1009, 'Faith', 'Nisperos', 6, 'Volleyball', 22, 'OH', 64.0, 1.79, 189),
(1009, 'Vanie', 'Gandler', 16, 'Volleyball', 21, 'MB', 69.0, 1.86, 145),
(1009, 'Lyann', 'DeGuzman', 9, 'Volleyball', 22, 'OH', 63.0, 1.77, 134),
(1009, 'AC', 'Miner', 11, 'Volleyball', 21, 'MB', 68.0, 1.83, 123),
(1009, 'Dani', 'Ravena', 5, 'Volleyball', 20, 'L', 59.0, 1.70, 106),
-- UP Lady Maroons Volleyball (6 players) - team_id 1010
(1010, 'Alyssa', 'Bertolano', 12, 'Volleyball', 22, 'S', 62.0, 1.74, 134),
(1010, 'Jewel', 'Lai', 18, 'Volleyball', 21, 'OH', 66.0, 1.81, 178),
(1010, 'Stephanie', 'Bustrillo', 21, 'Volleyball', 23, 'MB', 70.0, 1.87, 156),
(1010, 'Nina', 'Ytang', 7, 'Volleyball', 22, 'OH', 64.0, 1.79, 145),
(1010, 'Cassie', 'Lim', 14, 'Volleyball', 21, 'MB', 67.0, 1.84, 123),
(1010, 'Marist', 'Layug', 4, 'Volleyball', 20, 'L', 57.0, 1.67, 98),
-- UST Golden Tigresses Volleyball (6 players) - team_id 1011
(1011, 'Cassie', 'Carballo', 4, 'Volleyball', 22, 'S', 60.0, 1.73, 123),
(1011, 'Eya', 'Laure', 19, 'Volleyball', 23, 'OH', 65.0, 1.82, 189),
(1011, 'Xyza', 'Gula', 13, 'Volleyball', 21, 'MB', 68.0, 1.84, 134),
(1011, 'Imee', 'Hernandez', 8, 'Volleyball', 22, 'OH', 63.0, 1.78, 145),
(1011, 'Angge', 'Poyos', 11, 'Volleyball', 21, 'MB', 67.0, 1.85, 112),
(1011, 'KC', 'De Luna', 2, 'Volleyball', 20, 'L', 58.0, 1.69, 95),
-- FEU Lady Tamaraws Volleyball (6 players) - team_id 1012
(1012, 'Kyle', 'Negrito', 3, 'Volleyball', 21, 'S', 61.0, 1.75, 145),
(1012, 'Jean', 'Asis', 6, 'Volleyball', 22, 'OH', 64.0, 1.78, 167),
(1012, 'Ivana', 'Agudo', 17, 'Volleyball', 23, 'MB', 69.0, 1.85, 134),
(1012, 'Tin', 'Ubaldo', 9, 'Volleyball', 22, 'OH', 63.0, 1.77, 123),
(1012, 'Shiela', 'Kiseo', 12, 'Volleyball', 21, 'MB', 66.0, 1.83, 112),
(1012, 'Buding', 'Duremdes', 5, 'Volleyball', 20, 'L', 57.0, 1.68, 98),
-- UE Lady Warriors Volleyball (6 players) - team_id 1013
(1013, 'KC', 'Galdones', 1, 'Volleyball', 22, 'S', 60.0, 1.74, 123),
(1013, 'Kath', 'Arado', 26, 'Volleyball', 21, 'OH', 66.0, 1.80, 145),
(1013, 'Mary Rhose', 'Dapol', 12, 'Volleyball', 23, 'MB', 68.0, 1.83, 134),
(1013, 'Judith', 'Abil', 7, 'Volleyball', 22, 'OH', 64.0, 1.79, 123),
(1013, 'Casiey', 'Dongallo', 14, 'Volleyball', 21, 'MB', 67.0, 1.84, 112),
(1013, 'Ja-Rone', 'Kaal', 3, 'Volleyball', 20, 'L', 58.0, 1.70, 95),
-- NU Lady Bulldogs Volleyball (6 players) - team_id 1014
(1014, 'Joyme', 'Cagande', 10, 'Volleyball', 22, 'S', 61.0, 1.76, 156),
(1014, 'Ivy', 'Lacsina', 25, 'Volleyball', 21, 'OH', 65.0, 1.79, 167),
(1014, 'Bella', 'Belen', 15, 'Volleyball', 23, 'MB', 69.0, 1.86, 145),
(1014, 'Alyssa', 'Solomon', 8, 'Volleyball', 22, 'OH', 64.0, 1.78, 134),
(1014, 'Rosel', 'Predenciado', 13, 'Volleyball', 21, 'MB', 68.0, 1.85, 123),
(1014, 'Jen', 'Nierva', 6, 'Volleyball', 20, 'L', 57.0, 1.67, 106),
-- Adamson Lady Falcons Volleyball (6 players) - team_id 1015
(1015, 'Louie', 'Romero', 2, 'Volleyball', 21, 'S', 60.0, 1.73, 134),
(1015, 'Trisha', 'Genesis', 22, 'Volleyball', 22, 'OH', 64.0, 1.77, 156),
(1015, 'Lorene', 'Toring', 11, 'Volleyball', 23, 'MB', 68.0, 1.84, 123),
(1015, 'Lucille', 'Almonte', 5, 'Volleyball', 22, 'OH', 63.0, 1.76, 112),
(1015, 'May', 'Roque', 9, 'Volleyball', 21, 'MB', 67.0, 1.83, 106),
(1015, 'Kate', 'Santiago', 4, 'Volleyball', 20, 'L', 58.0, 1.69, 95);

-- Matches (12 datasets)
INSERT INTO `match` (event_id, match_type, match_time_start, match_time_end, status, score_summary)
VALUES
(1000, 'Elimination_Round', '14:00:00', '16:00:00', 'Completed', 'Men''s: DLSU 78 - ADMU 74'),
(1000, 'Elimination_Round', '16:30:00', '18:30:00', 'Completed', 'Men''s: UP 82 - NU 79'),
(1001, 'Elimination_Round', '16:00:00', '18:00:00', 'Completed', 'Men''s: UST 76 - FEU 72'),
(1002, 'Elimination_Round', '18:00:00', '20:00:00', 'Completed', 'Men''s: ADMU 85 - UE 68'),
(1003, 'Semifinals', '18:00:00', '20:30:00', 'Scheduled', NULL),
(1004, 'Finals', '18:00:00', '21:00:00', 'Scheduled', NULL),
(1005, 'Elimination_Round', '14:00:00', '17:00:00', 'Completed', 'Women''s: DLSU 3-1 UST'),
(1006, 'Elimination_Round', '14:00:00', '17:00:00', 'Completed', 'Women''s: ADMU 3-2 UP'),
(1007, 'Semifinals', '14:00:00', '18:00:00', 'Scheduled', NULL),
(1008, 'Elimination_Round', '16:00:00', '20:00:00', 'Completed', 'Men''s: NU 88 - FEU 81'),
(1009, 'Elimination_Round', '16:00:00', '18:00:00', 'Completed', 'Women''s: NU 3-0 UE'),
(1009, 'Elimination_Round', '18:30:00', '21:00:00', 'Completed', 'Women''s: FEU 3-1 ADMU');

-- Match Teams
INSERT INTO match_team (match_id, team_id, is_home, team_score)
VALUES
(1000, 1000, TRUE, 78), (1000, 1001, FALSE, 74),
(1001, 1002, TRUE, 82), (1001, 1006, FALSE, 79),
(1002, 1003, TRUE, 76), (1002, 1004, FALSE, 72),
(1003, 1001, TRUE, 85), (1003, 1005, FALSE, 68),
(1004, 1000, TRUE, 0), (1004, 1001, FALSE, 0),
(1005, 1000, TRUE, 0), (1005, 1002, FALSE, 0),
(1006, 1008, TRUE, 3), (1006, 1011, FALSE, 1),
(1007, 1009, TRUE, 3), (1007, 1010, FALSE, 2),
(1008, 1008, TRUE, 0), (1008, 1009, FALSE, 0),
(1009, 1006, TRUE, 88), (1009, 1004, FALSE, 81),
(1010, 1014, TRUE, 3), (1010, 1013, FALSE, 0),
(1011, 1012, TRUE, 3), (1011, 1009, FALSE, 1);

-- Basketball Quarter Scores
INSERT INTO match_quarter_score (match_id, team_id, quarter_no, quarter_points)
VALUES
-- Match 1000: DLSU 78 - ADMU 74
(1000, 1000, 1, 18), (1000, 1000, 2, 22), (1000, 1000, 3, 19), (1000, 1000, 4, 19),
(1000, 1001, 1, 20), (1000, 1001, 2, 18), (1000, 1001, 3, 17), (1000, 1001, 4, 19),
-- Match 1001: UP 82 - NU 79
(1001, 1002, 1, 21), (1001, 1002, 2, 19), (1001, 1002, 3, 22), (1001, 1002, 4, 20),
(1001, 1006, 1, 18), (1001, 1006, 2, 22), (1001, 1006, 3, 19), (1001, 1006, 4, 20),
-- Match 1002: UST 76 - FEU 72
(1002, 1003, 1, 19), (1002, 1003, 2, 18), (1002, 1003, 3, 20), (1002, 1003, 4, 19),
(1002, 1004, 1, 17), (1002, 1004, 2, 19), (1002, 1004, 3, 18), (1002, 1004, 4, 18),
-- Match 1003: ADMU 85 - UE 68
(1003, 1001, 1, 22), (1003, 1001, 2, 21), (1003, 1001, 3, 20), (1003, 1001, 4, 22),
(1003, 1005, 1, 16), (1003, 1005, 2, 18), (1003, 1005, 3, 17), (1003, 1005, 4, 17);

-- Volleyball Set Scores
INSERT INTO match_set_score (match_id, team_id, set_no, set_points)
VALUES
-- Match 1006: DLSU Lady Archers 3-1 UST Golden Tigresses
(1006, 1008, 1, 25), (1006, 1008, 2, 23), (1006, 1008, 3, 25), (1006, 1008, 4, 25),
(1006, 1011, 1, 22), (1006, 1011, 2, 25), (1006, 1011, 3, 20), (1006, 1011, 4, 18),
-- Match 1007: ADMU Blue Eagles (Women) 3-2 UP Lady Maroons
(1007, 1009, 1, 25), (1007, 1009, 2, 22), (1007, 1009, 3, 25), (1007, 1009, 4, 23), (1007, 1009, 5, 15),
(1007, 1010, 1, 23), (1007, 1010, 2, 25), (1007, 1010, 3, 20), (1007, 1010, 4, 25), (1007, 1010, 5, 12),
-- Match 1009 Game 1: NU Lady Bulldogs 3-0 UE Lady Warriors
(1009, 1014, 1, 25), (1009, 1014, 2, 25), (1009, 1014, 3, 25),
(1009, 1013, 1, 18), (1009, 1013, 2, 20), (1009, 1013, 3, 19),
-- Match 1009 Game 2: FEU Lady Tamaraws 3-1 ADMU Blue Eagles (Women)
(1009, 1012, 1, 25), (1009, 1012, 2, 22), (1009, 1012, 3, 25), (1009, 1012, 4, 25),
(1009, 1009, 1, 20), (1009, 1009, 2, 25), (1009, 1009, 3, 21), (1009, 1009, 4, 22);

-- Tickets
INSERT INTO ticket (ticket_type, default_price, price, ticket_status)
VALUES
('General Admission', 300.00, NULL, 'Active'),
('Upper Box', 500.00, NULL, 'Active'),
('Lower Box', 750.00, NULL, 'Active'),
('Courtside', 1200.00, NULL, 'Active'),
('Patron', 400.00, NULL, 'Active');

-- Customers
INSERT INTO customer (customer_first_name, customer_last_name, phone_number, email, organization, registration_date, preferred_team, customer_status, payment_method)
VALUES
('Carla', 'Reyes', '09170000001', 'carla.reyes@example.com', 'De La Salle University', '2025-09-01', 'De La Salle Green Archers', 'Active', 'GCash'),
('Miguel', 'Santos', '09170000002', 'miguel.santos@example.com', 'University of the Philippines', '2025-09-05', 'UP Fighting Maroons', 'Active', 'Credit Card'),
('Alyssa', 'Valdez', '09170000003', 'alyssa.valdez@example.com', 'Ateneo de Manila University', '2025-09-08', 'Ateneo Blue Eagles', 'Active', 'Debit Card'),
('Marco', 'Dela Cruz', '09170000004', 'marco.delacruz@example.com', 'UST', '2025-09-12', 'UST Growling Tigers', 'Active', 'GCash'),
('Sofia', 'Garcia', '09170000005', 'sofia.garcia@example.com', 'FEU', '2025-09-15', 'Far Eastern University Tamaraws', 'Active', 'PayMaya'),
('James', 'Tan', '09170000006', 'james.tan@example.com', 'National University', '2025-09-18', 'National University Bulldogs', 'Active', 'Credit Card'),
('Elena', 'Bautista', '09170000007', 'elena.bautista@example.com', 'Adamson University', '2025-09-20', 'Adamson Soaring Falcons', 'Active', 'GCash'),
('Robert', 'Cruz', '09170000008', 'robert.cruz@example.com', 'De La Salle University', '2025-09-25', 'De La Salle Green Archers', 'Active', 'Debit Card'),
('Maria', 'Lopez', '09170000009', 'maria.lopez@example.com', 'Ateneo de Manila University', '2025-09-28', 'Ateneo Blue Eagles', 'Active', 'Credit Card'),
('Juan', 'Rivera', '09170000010', 'juan.rivera@example.com', 'University of the Philippines', '2025-10-01', 'UP Fighting Maroons', 'Active', 'PayMaya');

-- Seats (200 seats - 120 Lower Box + 80 Upper Box for Mall of Asia Arena)
INSERT INTO seat (seat_type, venue_address, seat_status, ticket_id)
VALUES
-- Lower Box seats for Mall of Asia Arena (120 seats) - Seat IDs 1000-1119
('Lower Box', 'Mall of Asia Arena', 'Sold', 1002),
('Lower Box', 'Mall of Asia Arena', 'Sold', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
('Lower Box', 'Mall of Asia Arena', 'Available', 1002),
-- Upper Box seats for Mall of Asia Arena (80 seats) - Seat IDs 1120-1199
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
('Upper Box', 'Mall of Asia Arena', 'Available', 1001),
-- Additional seats for other venues (for testing)
('Lower Box', 'Smart Araneta Coliseum', 'Available', 1002),
('Upper Box', 'Smart Araneta Coliseum', 'Available', 1001),
('Lower Box', 'PhilSports Arena', 'Available', 1002),
('Upper Box', 'PhilSports Arena', 'Available', 1001),

-- ========== ADDITIONAL SEATS FOR ALL TICKET TYPES AND VENUES ==========

-- General Admission seats for Mall of Asia Arena (100 seats)
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),
('General Admission', 'Mall of Asia Arena', 'Available', 1000),

-- Courtside seats for Mall of Asia Arena (20 premium seats)
('Courtside', 'Mall of Asia Arena', 'Available', 1003),
('Courtside', 'Mall of Asia Arena', 'Available', 1003),
('Courtside', 'Mall of Asia Arena', 'Available', 1003),
('Courtside', 'Mall of Asia Arena', 'Available', 1003),
('Courtside', 'Mall of Asia Arena', 'Available', 1003),
('Courtside', 'Mall of Asia Arena', 'Available', 1003),
('Courtside', 'Mall of Asia Arena', 'Available', 1003),
('Courtside', 'Mall of Asia Arena', 'Available', 1003),
('Courtside', 'Mall of Asia Arena', 'Available', 1003),
('Courtside', 'Mall of Asia Arena', 'Available', 1003),
('Courtside', 'Mall of Asia Arena', 'Available', 1003),
('Courtside', 'Mall of Asia Arena', 'Available', 1003),
('Courtside', 'Mall of Asia Arena', 'Available', 1003),
('Courtside', 'Mall of Asia Arena', 'Available', 1003),
('Courtside', 'Mall of Asia Arena', 'Available', 1003),
('Courtside', 'Mall of Asia Arena', 'Available', 1003),
('Courtside', 'Mall of Asia Arena', 'Available', 1003),
('Courtside', 'Mall of Asia Arena', 'Available', 1003),
('Courtside', 'Mall of Asia Arena', 'Available', 1003),
('Courtside', 'Mall of Asia Arena', 'Available', 1003),

-- Patron seats for Mall of Asia Arena (30 VIP seats)
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),
('Patron', 'Mall of Asia Arena', 'Available', 1004),

-- Smart Araneta Coliseum (additional seats for all types)
('General Admission', 'Smart Araneta Coliseum', 'Available', 1000),
('General Admission', 'Smart Araneta Coliseum', 'Available', 1000),
('General Admission', 'Smart Araneta Coliseum', 'Available', 1000),
('General Admission', 'Smart Araneta Coliseum', 'Available', 1000),
('General Admission', 'Smart Araneta Coliseum', 'Available', 1000),
('General Admission', 'Smart Araneta Coliseum', 'Available', 1000),
('General Admission', 'Smart Araneta Coliseum', 'Available', 1000),
('General Admission', 'Smart Araneta Coliseum', 'Available', 1000),
('General Admission', 'Smart Araneta Coliseum', 'Available', 1000),
('General Admission', 'Smart Araneta Coliseum', 'Available', 1000),
('Patron', 'Smart Araneta Coliseum', 'Available', 1004),
('Patron', 'Smart Araneta Coliseum', 'Available', 1004),
('Patron', 'Smart Araneta Coliseum', 'Available', 1004),
('Patron', 'Smart Araneta Coliseum', 'Available', 1004),
('Patron', 'Smart Araneta Coliseum', 'Available', 1004),

-- PhilSports Arena (additional seats)
('General Admission', 'PhilSports Arena', 'Available', 1000),
('General Admission', 'PhilSports Arena', 'Available', 1000),
('General Admission', 'PhilSports Arena', 'Available', 1000),
('General Admission', 'PhilSports Arena', 'Available', 1000),
('General Admission', 'PhilSports Arena', 'Available', 1000),
('General Admission', 'PhilSports Arena', 'Available', 1000),
('General Admission', 'PhilSports Arena', 'Available', 1000),
('General Admission', 'PhilSports Arena', 'Available', 1000),
('General Admission', 'PhilSports Arena', 'Available', 1000),
('General Admission', 'PhilSports Arena', 'Available', 1000),

-- Ynares Center seats (NEW VENUE)
('General Admission', 'Ynares Center', 'Available', 1000),
('General Admission', 'Ynares Center', 'Available', 1000),
('General Admission', 'Ynares Center', 'Available', 1000),
('General Admission', 'Ynares Center', 'Available', 1000),
('General Admission', 'Ynares Center', 'Available', 1000),
('General Admission', 'Ynares Center', 'Available', 1000),
('General Admission', 'Ynares Center', 'Available', 1000),
('General Admission', 'Ynares Center', 'Available', 1000),
('General Admission', 'Ynares Center', 'Available', 1000),
('General Admission', 'Ynares Center', 'Available', 1000),
('Upper Box', 'Ynares Center', 'Available', 1001),
('Upper Box', 'Ynares Center', 'Available', 1001),
('Upper Box', 'Ynares Center', 'Available', 1001),
('Upper Box', 'Ynares Center', 'Available', 1001),
('Upper Box', 'Ynares Center', 'Available', 1001),
('Lower Box', 'Ynares Center', 'Available', 1002),
('Lower Box', 'Ynares Center', 'Available', 1002),
('Lower Box', 'Ynares Center', 'Available', 1002),
('Lower Box', 'Ynares Center', 'Available', 1002),
('Lower Box', 'Ynares Center', 'Available', 1002),

-- Filoil EcoOil Centre seats (NEW VENUE)
('General Admission', 'Filoil EcoOil Centre', 'Available', 1000),
('General Admission', 'Filoil EcoOil Centre', 'Available', 1000),
('General Admission', 'Filoil EcoOil Centre', 'Available', 1000),
('General Admission', 'Filoil EcoOil Centre', 'Available', 1000),
('General Admission', 'Filoil EcoOil Centre', 'Available', 1000),
('General Admission', 'Filoil EcoOil Centre', 'Available', 1000),
('General Admission', 'Filoil EcoOil Centre', 'Available', 1000),
('General Admission', 'Filoil EcoOil Centre', 'Available', 1000),
('General Admission', 'Filoil EcoOil Centre', 'Available', 1000),
('General Admission', 'Filoil EcoOil Centre', 'Available', 1000),
('Upper Box', 'Filoil EcoOil Centre', 'Available', 1001),
('Upper Box', 'Filoil EcoOil Centre', 'Available', 1001),
('Upper Box', 'Filoil EcoOil Centre', 'Available', 1001),
('Upper Box', 'Filoil EcoOil Centre', 'Available', 1001),
('Upper Box', 'Filoil EcoOil Centre', 'Available', 1001),
('Lower Box', 'Filoil EcoOil Centre', 'Available', 1002),
('Lower Box', 'Filoil EcoOil Centre', 'Available', 1002),
('Lower Box', 'Filoil EcoOil Centre', 'Available', 1002),
('Lower Box', 'Filoil EcoOil Centre', 'Available', 1002),
('Lower Box', 'Filoil EcoOil Centre', 'Available', 1002);

INSERT INTO seat_and_ticket (seat_id, event_id, customer_id, sale_datetime, quantity, unit_price, ticket_id, match_id, sale_status)
VALUES
-- Event 1000: Mall of Asia Arena (Completed) - 10 tickets
(1000, 1000, 1000, '2025-11-01 10:00:00', 2, 750.00, 1002, 1000, 'Sold'),
(1001, 1000, 1001, '2025-11-02 09:30:00', 2, 750.00, 1002, 1000, 'Sold'),
(1002, 1000, 1002, '2025-11-03 11:15:00', 2, 750.00, 1002, 1000, 'Sold'),
(1003, 1000, 1003, '2025-11-04 14:20:00', 2, 750.00, 1002, 1000, 'Sold'),
(1004, 1000, 1004, '2025-11-05 08:45:00', 2, 750.00, 1002, 1000, 'Sold'),
(1005, 1000, 1005, '2025-11-06 10:00:00', 2, 750.00, 1002, 1001, 'Sold'),
(1006, 1000, 1006, '2025-11-07 15:30:00', 2, 750.00, 1002, 1001, 'Sold'),
(1007, 1000, 1007, '2025-11-08 16:00:00', 2, 750.00, 1002, 1001, 'Sold'),
(1008, 1000, 1008, '2025-11-09 12:00:00', 2, 750.00, 1002, 1001, 'Sold'),
(1009, 1000, 1009, '2025-11-10 13:30:00', 2, 750.00, 1002, 1001, 'Sold'),

-- Event 1001: Smart Araneta Coliseum (Completed) - 8 tickets
(1010, 1001, 1000, '2025-11-15 10:00:00', 2, 750.00, 1002, 1002, 'Sold'),
(1011, 1001, 1001, '2025-11-16 11:00:00', 2, 750.00, 1002, 1002, 'Sold'),
(1012, 1001, 1002, '2025-11-17 12:00:00', 2, 750.00, 1002, 1002, 'Sold'),
(1013, 1001, 1003, '2025-11-18 13:00:00', 2, 750.00, 1002, 1002, 'Sold'),
(1014, 1001, 1004, '2025-11-19 14:00:00', 2, 750.00, 1002, 1002, 'Sold'),
(1015, 1001, 1005, '2025-11-19 15:00:00', 2, 750.00, 1002, 1002, 'Sold'),
(1016, 1001, 1006, '2025-11-19 16:00:00', 2, 750.00, 1002, 1002, 'Sold'),
(1017, 1001, 1007, '2025-11-19 17:00:00', 2, 750.00, 1002, 1002, 'Sold'),

-- Event 1002: PhilSports Arena (Completed) - 6 tickets
(1018, 1002, 1000, '2025-11-20 10:00:00', 2, 750.00, 1002, 1003, 'Sold'),
(1019, 1002, 1001, '2025-11-21 11:00:00', 2, 750.00, 1002, 1003, 'Sold'),
(1020, 1002, 1002, '2025-11-22 12:00:00', 2, 750.00, 1002, 1003, 'Sold'),
(1021, 1002, 1003, '2025-11-23 13:00:00', 2, 750.00, 1002, 1003, 'Sold'),
(1022, 1002, 1004, '2025-11-24 14:00:00', 2, 750.00, 1002, 1003, 'Sold'),
(1023, 1002, 1005, '2025-11-24 15:00:00', 2, 750.00, 1002, 1003, 'Sold'),

-- Event 1008: Ynares Center (Completed) - 5 tickets
(1024, 1008, 1006, '2025-11-23 10:00:00', 2, 750.00, 1002, 1008, 'Sold'),
(1025, 1008, 1007, '2025-11-24 11:00:00', 2, 750.00, 1002, 1008, 'Sold'),
(1026, 1008, 1008, '2025-11-25 12:00:00', 2, 750.00, 1002, 1008, 'Sold'),
(1027, 1008, 1009, '2025-11-26 13:00:00', 2, 750.00, 1002, 1008, 'Sold'),
(1028, 1008, 1000, '2025-11-27 14:00:00', 2, 750.00, 1002, 1008, 'Sold'),

-- Event 1005: Mall of Asia Arena - Women's Volleyball (Completed) - 6 tickets
(1029, 1005, 1001, '2025-11-10 10:00:00', 2, 750.00, 1002, 1006, 'Sold'),
(1030, 1005, 1002, '2025-11-11 11:00:00', 2, 750.00, 1002, 1006, 'Sold'),
(1031, 1005, 1003, '2025-11-12 12:00:00', 2, 750.00, 1002, 1006, 'Sold'),
(1032, 1005, 1004, '2025-11-13 13:00:00', 2, 750.00, 1002, 1006, 'Sold'),
(1033, 1005, 1005, '2025-11-14 14:00:00', 2, 750.00, 1002, 1006, 'Sold'),
(1034, 1005, 1006, '2025-11-15 15:00:00', 2, 750.00, 1002, 1006, 'Sold'),

-- Event 1006: Smart Araneta Coliseum - Women's Volleyball (Completed) - 5 tickets
(1035, 1006, 1007, '2025-11-17 10:00:00', 2, 750.00, 1002, 1007, 'Sold'),
(1036, 1006, 1008, '2025-11-18 11:00:00', 2, 750.00, 1002, 1007, 'Sold'),
(1037, 1006, 1009, '2025-11-19 12:00:00', 2, 750.00, 1002, 1007, 'Sold'),
(1038, 1006, 1000, '2025-11-20 13:00:00', 2, 750.00, 1002, 1007, 'Sold'),
(1039, 1006, 1001, '2025-11-21 14:00:00', 2, 750.00, 1002, 1007, 'Sold');

-- Ticket Refund Audit
INSERT INTO ticket_refund_audit (seat_and_ticket_rec_id, refund_amount, reason, processed_by)
VALUES
(1002, 1200.00, 'Bad Service!', 'Ticketing Desk Supervisor'),
(1000, 750.00, 'Customer unable to attend due to personal emergency', 'Refund Processing Team'),
(1001, 750.00, 'Event rescheduled - customer conflict', 'Ticketing Manager'),
(1003, 500.00, 'Wrong seat category purchased', 'Customer Service Representative'),
(1004, 1200.00, 'Duplicate purchase - customer error', 'Ticketing Desk Supervisor'),
(1005, 1200.00, 'Medical emergency - hospitalization', 'Refund Processing Team'),
(1006, 500.00, 'Poor viewing experience - obstructed view', 'Venue Manager'),
(1007, 750.00, 'Customer dissatisfied with facilities', 'Customer Relations Manager'),
(1008, 300.00, 'Event cancelled by organizer', 'Ticketing Manager'),
(1009, 400.00, 'Customer requested refund within 24 hours of purchase', 'Customer Service Representative');

-- Event Personnel (10 datasets)
INSERT INTO event_personnel (personnel_first_name, personnel_last_name, availability_status, role, affiliation, contact_no, event_id, match_id)
VALUES
('Mariel', 'Flores', 'Confirmed', 'Usher', 'Mall of Asia Arena Events', '0917-000-1111', 1000, 1000),
('Paolo', 'Reyes', 'Confirmed', 'Referee', 'UAAP Officials Pool', '0917-000-2222', 1001, 1002),
('Angela', 'Santos', 'Confirmed', 'Host', 'Smart Communications', '0917-000-3333', 1002, 1003),
('Ricardo', 'Martinez', 'Confirmed', 'Security', 'PhilSports Security Services', '0917-000-4444', 1002, 1003),
('Linda', 'Villanueva', 'Confirmed', 'Scorekeeper', 'UAAP Stat Crew', '0917-000-5555', 1005, 1006),
('Carlos', 'Aquino', 'Confirmed', 'Ticketing Agent', 'SM Tickets', '0917-000-6666', 1005, 1006),
('Grace', 'Ramos', 'Confirmed', 'Cheerleader', 'DLSU Animo Squad', '0917-000-7777', 1000, 1001),
('Daniel', 'Torres', 'Confirmed', 'Stat Crew', 'UAAP Statistics Department', '0917-000-8888', 1006, 1007),
('Isabel', 'Fernandez', 'Confirmed', 'Singer', 'ABS-CBN Events', '0917-000-9999', 1000, 1000),
('Ramon', 'Garcia', 'Confirmed', 'Halftime Entertainment', 'UAAP Entertainment Group', '0917-001-0000', 1008, 1008);
